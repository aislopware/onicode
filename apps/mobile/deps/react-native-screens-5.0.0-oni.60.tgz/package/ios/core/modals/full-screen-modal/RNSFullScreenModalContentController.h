#pragma once

#import <UIKit/UIKit.h>
#import "RNSFullScreenModalAnimation.h"
#import "RNSFullScreenModalPresentationStyle.h"
#import "RNSFullScreenModalProviders.h"

NS_ASSUME_NONNULL_BEGIN

@class RNSFullScreenModalContentView;
@class RNSFullScreenModalContentController;

@protocol RNSFullScreenModalContentControllerDelegate <NSObject>
- (void)modalControllerViewDidLayoutSubviews:(RNSFullScreenModalContentController *)controller;

- (void)modalControllerViewWillAppear:(RNSFullScreenModalContentController *)controller;
- (void)modalControllerViewDidAppear:(RNSFullScreenModalContentController *)controller;
- (void)modalControllerViewWillDisappear:(RNSFullScreenModalContentController *)controller;
- (void)modalControllerViewDidDisappear:(RNSFullScreenModalContentController *)controller;

/// The programmatic dismissal requested by `isOpen == NO` has completed.
- (void)modalControllerDidDismiss:(RNSFullScreenModalContentController *)controller;

/**
 * The modal left the presentation hierarchy while `isOpen` was still `YES`,
 * e.g. UIKit took it down together with a controller below it.
 */
- (void)modalControllerDidNativeDismiss:(RNSFullScreenModalContentController *)controller;
@end

@interface RNSFullScreenModalContentController : UIViewController

@property (nonatomic, weak, nullable) id<RNSFullScreenModalContentControllerDelegate> delegate;

@property (nonatomic, weak, nullable) id<RNSFullScreenModalPresentationProvider> presentationProvider;

@property (nonatomic, readonly, nonnull) RNSFullScreenModalContentView *contentView;

/**
 * Must be set only while the controller is dismissed: UIKit does not support
 * changing `modalPresentationStyle` of a presented controller.
 */
@property (nonatomic) RNSFullScreenModalPresentationStyle presentationStyle;

/// Sets `modalTransitionStyle`. UIKit reads it at both presentation and dismissal.
@property (nonatomic) RNSFullScreenModalAnimation animation;

/// Whether presentation and dismissal are animated: `NO` for `RNSFullScreenModalAnimationNone`.
@property (nonatomic, readonly) BOOL isAnimated;

#pragma mark - Signals

- (void)setNeedsPresentationUpdate;

#pragma mark - Updates

- (void)flushPendingUpdates;

@end

NS_ASSUME_NONNULL_END
