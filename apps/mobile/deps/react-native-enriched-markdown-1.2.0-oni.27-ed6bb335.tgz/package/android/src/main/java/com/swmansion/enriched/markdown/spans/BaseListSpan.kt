package com.swmansion.enriched.markdown.spans

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.text.Layout
import android.text.Spanned
import android.text.TextPaint
import android.text.style.LeadingMarginSpan
import android.text.style.MetricAffectingSpan
import com.swmansion.enriched.markdown.renderer.BlockStyle
import com.swmansion.enriched.markdown.renderer.SpanStyleCache
import com.swmansion.enriched.markdown.utils.text.extensions.applyBlockStyleFont
import com.swmansion.enriched.markdown.utils.text.extensions.applyColorPreserving

abstract class BaseListSpan(
  val depth: Int,
  protected val context: Context,
  protected val styleCache: SpanStyleCache,
  protected val blockStyle: BlockStyle,
  protected val marginLeft: Float,
  protected val gapWidth: Float,
  internal val drawsMarker: Boolean = true,
  internal val ancestorMarkerOffset: Float = 0f,
  internal val parentMarkerWidth: Float? = null,
) : MetricAffectingSpan(),
  LeadingMarginSpan {
  private var cachedText: CharSequence? = null
  private var cachedHasDeeperSpanByPosition = mutableMapOf<Int, Boolean>()

  val markerFontMetrics: Paint.FontMetrics by lazy {
    TextPaint()
      .apply {
        applyBlockStyleFont(blockStyle, context)
        textSize = blockStyle.fontSize
      }.fontMetrics
  }

  protected abstract fun getMarkerWidth(): Float

  /** How far an ordered list widened this item's column past the one short lists reserve. */
  internal open val markerExtraWidth: Float = 0f

  /** The rest of an item a lifted table split off: not a list item of its own to accessibility. */
  internal var continuesItem = false

  /** For a continuation in an ordered list: the number of the item it continues. */
  internal var continuedNumber: Int? = null

  /** The head of an item that opened with a lifted table: its marker draws on the item's otherwise blank line. */
  internal var drawsOnBlankLine = false

  /** This item's marker column without [markerExtraWidth]; a nested item measures its indent against it. */
  internal open val baselineMarkerWidth: Float get() = getMarkerWidth()

  override fun updateMeasureState(textPaint: TextPaint) = applyTextStyle(textPaint)

  override fun updateDrawState(textPaint: TextPaint) = applyTextStyle(textPaint)

  override fun getLeadingMargin(first: Boolean): Int {
    val effectiveGap = gapWidth.coerceAtLeast(DEFAULT_MIN_GAP)
    if (depth == 0) return (getMarkerWidth() + effectiveGap).toInt()

    // Subtract truncated absolute indents, each measured from its own item's column, so neither mixed
    // columns nor fractional margins accumulate rounding. The widenings are whole pixels and add unchanged.
    val markerWidth = baselineMarkerWidth
    val parentWidth = parentMarkerWidth ?: markerWidth
    val indent = (depth * marginLeft + markerWidth + effectiveGap).toInt()
    val parentIndent = ((depth - 1) * marginLeft + parentWidth + effectiveGap).toInt()
    return indent - parentIndent + markerExtraWidth.toInt()
  }

  override fun drawLeadingMargin(
    canvas: Canvas,
    paint: Paint,
    x: Int,
    dir: Int,
    top: Int,
    baseline: Int,
    bottom: Int,
    text: CharSequence?,
    start: Int,
    end: Int,
    first: Boolean,
    layout: Layout?,
  ) {
    if (!drawsMarker) return
    if (!first || shouldSkipDrawing(text, start) || (!drawsOnBlankLine && !hasContent(text, start, end))) return

    // Only draw the marker on the true first line of this span.
    // \n inside list item content creates inner paragraphs, each with first=true,
    // but only the line at the span start should get a bullet/number.
    if (text is Spanned && text.getSpanStart(this) != start) return

    drawMarkerAt(canvas, paint, x, dir, top, baseline, bottom, layout, start)
  }

  fun drawMarkerAt(
    canvas: Canvas,
    paint: Paint,
    x: Int,
    dir: Int,
    top: Int,
    baseline: Int,
    bottom: Int,
    layout: Layout?,
    start: Int,
  ) {
    // A streaming effect's first character takes the marker with it.
    val visibility = streamingVisibility(layout?.text, start, start + 1)
    if (visibility <= 0f) return
    val layer =
      if (visibility < 1f) {
        val bounds = canvas.clipBounds
        canvas.saveLayerAlpha(bounds.left.toFloat(), top.toFloat(), bounds.right.toFloat(), bottom.toFloat(), (visibility * 255).toInt())
      } else {
        -1
      }
    val originalStyle = paint.style
    val originalColor = paint.color
    drawMarker(canvas, paint, x, dir, top, baseline, bottom, layout, start)
    paint.style = originalStyle
    paint.color = originalColor
    if (layer >= 0) canvas.restoreToCount(layer)
  }

  protected abstract fun drawMarker(
    canvas: Canvas,
    paint: Paint,
    x: Int,
    dir: Int,
    top: Int,
    baseline: Int,
    bottom: Int,
    layout: Layout?,
    start: Int,
  )

  @SuppressLint("WrongConstant")
  private fun applyTextStyle(textPaint: TextPaint) {
    textPaint.textSize = blockStyle.fontSize

    val preservedStyle = (textPaint.typeface?.style ?: 0) and BOLD_ITALIC_MASK
    textPaint.applyBlockStyleFont(blockStyle, context)
    if (preservedStyle != 0) {
      textPaint.typeface?.let { base -> textPaint.typeface = Typeface.create(base, preservedStyle) }
    }

    textPaint.applyColorPreserving(blockStyle.color, *styleCache.colorsToPreserve)
  }

  companion object {
    private const val BOLD_ITALIC_MASK = Typeface.BOLD or Typeface.ITALIC
    private const val DEFAULT_MIN_GAP = 4f
  }

  private fun hasContent(
    text: CharSequence?,
    start: Int,
    end: Int,
  ): Boolean {
    if (text == null || end <= start) return false
    return (start until end).any { !text[it].isWhitespace() }
  }

  private fun shouldSkipDrawing(
    text: CharSequence?,
    start: Int,
  ): Boolean {
    if (text !is Spanned) return false

    if (cachedText !== text) {
      cachedText = text
      cachedHasDeeperSpanByPosition.clear()
    }

    return cachedHasDeeperSpanByPosition.getOrPut(start) {
      val spans = text.getSpans(start, start + 1, BaseListSpan::class.java)
      spans.any { it.depth > depth }
    }
  }
}
