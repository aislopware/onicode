package com.swmansion.rnscreens.legacy.bottomsheet

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.AnimatorSet
import android.animation.ValueAnimator
import android.graphics.Rect
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.swmansion.rnscreens.legacy.Screen
import com.swmansion.rnscreens.legacy.ScreenStackFragment
import com.swmansion.rnscreens.legacy.events.ScreenAnimationDelegate
import com.swmansion.rnscreens.legacy.events.ScreenEventEmitter
import com.swmansion.rnscreens.legacy.ext.asScreenStackFragment
import com.swmansion.rnscreens.legacy.transition.ExternalBoundaryValuesEvaluator
import java.lang.ref.WeakReference

internal class SheetAnimationCoordinator(
    screen: Screen,
) {
    private val screenRef = WeakReference(screen)
    private val screen: Screen get() =
        checkNotNull(screenRef.get()) {
            "[RNScreens] Screen has been destroyed and shouldn't be the subject of any animations"
        }
    private var activeKeyboardAnimationsCount: Int = 0
    private val isKeyboardAnimationInProgress: Boolean
        get() = activeKeyboardAnimationsCount > 0
    private var isSheetAnimationInProgress: Boolean = false
    private var currentContentAnimator: ValueAnimator? = null

    /**
     * translationY the resize animation offsets from and returns to, captured when the animation
     * starts. Null when no resize animation runs - then it is simply the current translationY.
     */
    private var resizeAnimationOriginTranslationY: Float? = null

    private var lastKeyboardBottomOffset: Int = 0
    private var lastScreenContainerBottomOffset: Int = 0
    private val screenContainerRect = android.graphics.Rect()

    private var lastBottomSystemBarInset: Int = 0

    internal fun createSheetEnterAnimator(sheetAnimationContext: SheetDelegate.SheetAnimationContext): Animator {
        val animatorSet = AnimatorSet()

        val dimmingDelegate = sheetAnimationContext.dimmingDelegate
        val screenStackFragment = sheetAnimationContext.fragment

        val alphaAnimator = createDimmingViewAlphaAnimator(0f, dimmingDelegate.maxAlpha, dimmingDelegate)
        val slideAnimator = createSheetSlideInAnimator()

        animatorSet
            .play(slideAnimator)
            .takeIf {
                dimmingDelegate.willDimForDetentIndex(screen, screen.sheetInitialDetentIndex)
            }?.with(alphaAnimator)

        attachCommonListeners(animatorSet, isEnter = true, screenStackFragment)

        return animatorSet
    }

    internal fun createSheetExitAnimator(sheetAnimationContext: SheetDelegate.SheetAnimationContext): Animator {
        val animatorSet = AnimatorSet()

        val coordinatorLayout = sheetAnimationContext.coordinatorLayout
        val dimmingDelegate = sheetAnimationContext.dimmingDelegate
        val screenStackFragment = sheetAnimationContext.fragment

        val alphaAnimator =
            createDimmingViewAlphaAnimator(dimmingDelegate.dimmingView.alpha, 0f, dimmingDelegate)
        val slideAnimator = createSheetSlideOutAnimator(coordinatorLayout)

        animatorSet.play(alphaAnimator).with(slideAnimator)

        attachCommonListeners(animatorSet, isEnter = false, screenStackFragment)

        return animatorSet
    }

    /**
     * This should be used only with sheet in `fitToContents` mode.
     *
     * If an entry/exit animation is already in progress, we silently update the
     * behavior metrics and view layout without starting a competing translationY
     * animation - this is the fix for the race condition between the slide-in
     * ValueAnimator and externally triggered layout pass (e.g. applying padding from SAV insets).
     */
    internal fun updateSheetContentHeightWithAnimation(
        behavior: BottomSheetBehavior<Screen>,
        newHeight: Int,
    ) {
        val originTranslationY = resizeAnimationOriginTranslationY ?: screen.translationY

        /*
         * WHY OVERFLOW MATTERS:
         * BottomSheetBehavior has a physical limit (maxHeight) defined by the parent container.
         * If the new content height exceeds this limit (by its size or keyboard offset), simply
         * animating translationY back to its origin would attempt to render the sheet
         * larger than the screen.
         *
         * We need to constrain the height within the container's bounds.
         * By including this overflow to our animation, we ensure the sheet stops
         * expanding exactly at the maxHeight, preventing from being pushed
         * off-screen or causing layout synchronization issues with the CoordinatorLayout.
         */
        val clampedNewHeight = screen.resolveClampedHeight(newHeight, originTranslationY)

        // If an entry/exit animation or a keyboard animation is in progress - it owns
        // translationY writes. Then when the content size is changing, we silently
        // update behavior metrics and re-layout so the ongoing slide animation
        // lands at the correct final geometry, without firing a competing animation.
        if (isSheetAnimationInProgress || isKeyboardAnimationInProgress) {
            behavior.updateMetrics(clampedNewHeight)
            screen.layoutBottomSheetAtHeight(clampedNewHeight)
            screen.finalizeBottomSheetLayoutUpdates()
            return
        }

        // Compare with screen.height, because that is where the animation visually starts from, also when
        // interrupting a running one. Equal heights are a no-op only when no resize animation is running,
        // otherwise translationY still has to get back to the origin.
        if (clampedNewHeight == screen.height && resizeAnimationOriginTranslationY == null) return

        if (clampedNewHeight >= screen.height) {
            animateContentExpanding(behavior, clampedNewHeight, originTranslationY)
        } else {
            animateContentShrinking(behavior, clampedNewHeight, originTranslationY)
        }
    }

    /*
     * Expanding content animation:
     *
     * Before animation, we're updating the SheetBehavior - the maximum height is the new
     * content height, then we're forcing a layout pass. This ensures the view calculates
     * with its new bounds when the animation starts.
     *
     * In the animation, we're translating the Screen back to its origin position, providing
     * an impression that FormSheet expands. It already has the final size, but some content
     * is not yet visible on the screen. The animation starts from wherever the Screen is drawn
     * right now, so interrupting a running content animation is a plain retarget.
     *
     * After animation, we just need to send a notification that ShadowTree state should be updated,
     * as the positioning of pressables has changed due to the Y translation manipulation.
     */
    private fun animateContentExpanding(
        behavior: BottomSheetBehavior<Screen>,
        clampedNewHeight: Int,
        originTranslationY: Float,
    ) {
        // The layout grows upwards by the height difference - translate the Screen down by the
        // same amount so that it stays drawn where it is.
        screen.translationY += clampedNewHeight - screen.height
        cancelCurrentContentAnimation()
        resizeAnimationOriginTranslationY = originTranslationY
        currentContentAnimator =
            ValueAnimator.ofFloat(screen.translationY, originTranslationY).apply {
                addListener(
                    object : AnimatorListenerAdapter() {
                        override fun onAnimationStart(animation: Animator) {
                            behavior.updateMetrics(clampedNewHeight)
                            screen.layoutBottomSheetAtHeight(clampedNewHeight)
                        }

                        override fun onAnimationEnd(animation: Animator) {
                            currentContentAnimator = null
                            resizeAnimationOriginTranslationY = null
                            screen.finalizeBottomSheetLayoutUpdates()
                        }
                    },
                )
                addUpdateListener { screen.translationY = it.animatedValue as Float }
                start()
            }
    }

    /*
     * Shrinking content animation:
     *
     * Before the animation, I'm updating sheet metrics to the target value - the layout is not updated until
     * the end action. This is done deliberately: the Screen keeps its current size during the whole animation,
     * therefore there is no view clipping, and a height change arriving mid-animation is measured against
     * that still-laid-out size.
     *
     * In the animation, we're translating the Screen down to the position at which the current layout shows
     * the final geometry (origin + height difference), providing an impression that FormSheet shrinks.
     *
     * After animation, we can update the layout: the maximum FormSheet height is updated and we're forcing
     * another layout pass. Additionally, since the actual layout and the target position are equal,
     * we can reset translationY to the origin.
     *
     * After animation, we need to send a notification that ShadowTree state should be updated,
     * as the FormSheet size has changed and the positioning of pressables has changed due to the Y translation manipulation.
     */
    private fun animateContentShrinking(
        behavior: BottomSheetBehavior<Screen>,
        clampedNewHeight: Int,
        originTranslationY: Float,
    ) {
        val targetTranslationY = originTranslationY + (screen.height - clampedNewHeight)
        cancelCurrentContentAnimation()
        resizeAnimationOriginTranslationY = originTranslationY
        // Start animation from where the sheet is drawn to properly handle the translationY origin,
        // when this content change is interrupting another content resize animation.
        currentContentAnimator =
            ValueAnimator.ofFloat(screen.translationY, targetTranslationY).apply {
                addListener(
                    object : AnimatorListenerAdapter() {
                        override fun onAnimationStart(animation: Animator) {
                            behavior.updateMetrics(clampedNewHeight)
                        }

                        override fun onAnimationEnd(animation: Animator) {
                            currentContentAnimator = null
                            resizeAnimationOriginTranslationY = null
                            screen.layoutBottomSheetAtHeight(clampedNewHeight)
                            screen.translationY = originTranslationY
                            screen.finalizeBottomSheetLayoutUpdates()
                        }
                    },
                )
                addUpdateListener { screen.translationY = it.animatedValue as Float }
                start()
            }
    }

    internal fun notifyKeyboardAnimationStart() {
        activeKeyboardAnimationsCount++
        updateScreenContainerBottomOffset()
    }

    internal fun notifyKeyboardAnimationEnd() {
        activeKeyboardAnimationsCount = maxOf(0, activeKeyboardAnimationsCount - 1)
    }

    internal fun handleKeyboardInsetsProgress(insets: WindowInsetsCompat) {
        lastKeyboardBottomOffset = insets.getInsets(WindowInsetsCompat.Type.ime()).bottom
        lastBottomSystemBarInset = insets.getInsets(WindowInsetsCompat.Type.systemBars()).bottom
        // Prioritize enter/exit animations over direct keyboard inset reactions.
        // We store the latest keyboard offset in `lastKeyboardBottomOffset`
        // so that it can always be respected when applying translations in `updateSheetTranslationY`.
        //
        // This approach allows screen translation to be triggered from two sources, but without messing them together:
        // - During enter/exit animations, while accounting for the keyboard height.
        // - While interacting with a TextInput inside the bottom sheet, to handle keyboard show/hide events.
        if (!isSheetAnimationInProgress) {
            updateSheetTranslationY(0f)
        }
    }

    // This function calculates the Y offset to which the FormSheet should animate
    // when appearing (entering) or disappearing (exiting) with the on-screen keyboard (IME) present.
    // Its purpose is to ensure the FormSheet does not exceed the top edge of the screen.
    // It tries to display the FormSheet fully above the keyboard when there's enough space.
    // Otherwise, it shifts the sheet as high as possible, even if it means part of its content
    // will remain hidden behind the keyboard.
    private fun computeSheetOffsetYWithIMEPresent(keyboardHeight: Int): Int {
        val containerHeight =
            screen.fragment
                ?.asScreenStackFragment()
                ?.sheetDelegate
                ?.tryResolveMaxFormSheetHeight()
        check(containerHeight != null) {
            "[RNScreens] Failed to find window height during bottom sheet behaviour configuration"
        }

        if (screen.isSheetFitToContents()) {
            val contentHeight = screen.contentWrapper?.height ?: 0
            val offsetFromTop = maxOf(containerHeight - contentHeight, 0)
            // If the content is higher than the Screen, offsetFromTop becomes negative.
            // In such cases, we return 0 because a negative translation would shift the Screen
            // to the bottom, which is not intended.
            return minOf(offsetFromTop, keyboardHeight)
        }

        val detents = screen.sheetDetents

        val detentValue = detents.highest().coerceIn(0.0, 1.0)
        val sheetHeight = (detentValue * containerHeight).toInt()
        val offsetFromTop = containerHeight - sheetHeight

        return minOf(offsetFromTop, keyboardHeight)
    }

    private fun updateScreenContainerBottomOffset() {
        screen.container?.let { container ->
            if (container.isLaidOut && container.height > 0) {
                container.getGlobalVisibleRect(screenContainerRect)
                lastScreenContainerBottomOffset = maxOf(0, container.rootView.height - screenContainerRect.bottom)
            }
        }
    }

    private fun updateSheetTranslationY(baseTranslationY: Float) {
        screen.translationY = baseTranslationY - calculateKeyboardShiftHidingBottomInset()
    }

    private fun calculateKeyboardShiftHidingBottomInset(): Float {
        // Calculate how much of the keyboard physically intersects with our container.
        val keyboardHeightInContainerBounds = maxOf(0, lastKeyboardBottomOffset - lastScreenContainerBottomOffset)

        if (keyboardHeightInContainerBounds <= 0) {
            return 0f
        }

        // Determine the maximum upward shift needed to keep the content above the keyboard.
        val maxAllowedUpwardShift = computeSheetOffsetYWithIMEPresent(keyboardHeightInContainerBounds).toFloat()

        // Determine how much of the navigation bar is located within our container's bounds.
        val navigationBarHeightWithinContainer = maxOf(0, lastBottomSystemBarInset - lastScreenContainerBottomOffset)

        // By subtracting the nav bar height from our shift, we let that empty padding slide behind
        // the keyboard. This keeps the sheet's actual content flush against the keyboard's top edge
        // without requiring size updates.
        return maxOf(0f, maxAllowedUpwardShift - navigationBarHeightWithinContainer.toFloat())
    }

    private fun createSheetSlideInAnimator(): ValueAnimator {
        val startValueCallback = { _: Number? -> screen.height.toFloat() }
        val evaluator = ExternalBoundaryValuesEvaluator(startValueCallback, { 0f })

        return ValueAnimator.ofObject(evaluator, screen.height.toFloat(), 0f).apply {
            addUpdateListener { updateSheetTranslationY(it.animatedValue as Float) }
        }
    }

    private fun createSheetSlideOutAnimator(coordinatorLayout: CoordinatorLayout): ValueAnimator {
        val endValue = (coordinatorLayout.bottom - screen.top - screen.translationY)

        return ValueAnimator.ofFloat(0f, endValue).apply {
            addUpdateListener {
                updateSheetTranslationY(it.animatedValue as Float)
            }
        }
    }

    private fun createDimmingViewAlphaAnimator(
        from: Float,
        to: Float,
        dimmingDelegate: DimmingViewManager,
    ): ValueAnimator =
        ValueAnimator.ofFloat(from, to).apply {
            addUpdateListener { animator ->
                (animator.animatedValue as? Float)?.let {
                    dimmingDelegate.dimmingView.alpha = it
                }
            }
        }

    private fun cancelCurrentContentAnimation() {
        currentContentAnimator?.removeAllListeners()
        currentContentAnimator?.removeAllUpdateListeners()
        currentContentAnimator?.cancel()
        currentContentAnimator = null
        resizeAnimationOriginTranslationY = null
    }

    private fun Screen.layoutBottomSheetAtHeight(height: Int) = layout(left, bottom - height, right, bottom)

    private fun Screen.finalizeBottomSheetLayoutUpdates() {
        // Force a layout pass on the CoordinatorLayout to synchronize BottomSheetBehavior's
        // internal offsets with the new maxHeight. This prevents the sheet from snapping back
        // to its old position when the user starts a gesture.
        parent.requestLayout()

        // Notify that ShadowTree state should be updated, as the positioning of pressables
        // has changed due to the Y translation manipulation.
        onSheetYTranslationChanged()
    }

    private fun attachCommonListeners(
        animatorSet: AnimatorSet,
        isEnter: Boolean,
        screenStackFragment: ScreenStackFragment,
    ) {
        animatorSet.addListener(
            ScreenAnimationDelegate(
                screenStackFragment,
                ScreenEventEmitter(screen),
                if (isEnter) {
                    ScreenAnimationDelegate.AnimationType.ENTER
                } else {
                    ScreenAnimationDelegate.AnimationType.EXIT
                },
            ),
        )

        animatorSet.addListener(
            object : AnimatorListenerAdapter() {
                override fun onAnimationStart(animation: Animator) {
                    isSheetAnimationInProgress = true
                    updateScreenContainerBottomOffset()
                }

                override fun onAnimationCancel(animation: Animator) {
                    isSheetAnimationInProgress = false
                }

                override fun onAnimationEnd(animation: Animator) {
                    isSheetAnimationInProgress = false

                    screen.onSheetYTranslationChanged()
                }
            },
        )
    }
}
