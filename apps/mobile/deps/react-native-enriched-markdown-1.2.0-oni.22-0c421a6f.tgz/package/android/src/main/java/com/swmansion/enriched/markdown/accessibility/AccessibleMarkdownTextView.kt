package com.swmansion.enriched.markdown.accessibility

import android.content.Context
import android.graphics.Canvas
import android.graphics.Rect
import android.text.TextDirectionHeuristic
import android.util.AttributeSet
import android.view.ActionMode
import android.view.KeyEvent
import android.view.MotionEvent
import androidx.appcompat.widget.AppCompatTextView
import com.swmansion.enriched.markdown.spans.InlineBackgroundGeometry
import com.swmansion.enriched.markdown.spans.LinkPillSpan
import com.swmansion.enriched.markdown.utils.common.layout.MarkdownTextDirection
import com.swmansion.enriched.markdown.utils.common.layout.MarkdownWritingDirection
import com.swmansion.enriched.markdown.utils.text.span.prepareWidthAwareSpans
import com.swmansion.enriched.markdown.utils.text.view.OnSelectionCopy
import com.swmansion.enriched.markdown.utils.text.view.SelectionCopyFormat
import com.swmansion.enriched.markdown.utils.text.view.copySelection

/** AppCompatTextView with built-in TalkBack support via MarkdownAccessibilityHelper. */
abstract class AccessibleMarkdownTextView
  @JvmOverloads
  constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
  ) : AppCompatTextView(context, attrs, defStyleAttr) {
    val accessibilityHelper = MarkdownAccessibilityHelper(this)
    var onSelectionCopyCallback: OnSelectionCopy? = null

    /** The selection toolbar while it is showing, kept up to date by the selection menu callback. */
    internal var selectionActionMode: ActionMode? = null

    // Nullable: TextView's constructor sets text and asks for the heuristic before this class initializes.
    private val markdownTextDirection: MarkdownTextDirection? = MarkdownTextDirection()

    var writingDirection: MarkdownWritingDirection
      get() = markdownTextDirection?.writingDirection ?: MarkdownWritingDirection.FIRST_STRONG
      set(value) {
        // TextView caches the heuristic and only asks again when RTL properties change.
        if (markdownTextDirection?.update(value, text) == true) onRtlPropertiesChanged(layoutDirection)
      }

    override fun getTextDirectionHeuristic(): TextDirectionHeuristic =
      markdownTextDirection?.heuristic(layoutDirection == LAYOUT_DIRECTION_RTL) ?: super.getTextDirectionHeuristic()

    // The selection menu's Copy ends up here, and Ctrl+C (and TalkBack's copy action) call this directly.
    override fun onTextContextMenuItem(id: Int): Boolean {
      if (id == android.R.id.copy) {
        // The platform's copy is what tells the user when the clipboard refuses the clip.
        if (!copySelection(SelectionCopyFormat.PLAIN, onSelectionCopyCallback)) {
          return super.onTextContextMenuItem(id)
        }
        selectionActionMode?.finish()
        return true
      }
      return super.onTextContextMenuItem(id)
    }

    override fun setText(
      text: CharSequence?,
      type: BufferType?,
    ) {
      // Prime pills and images before the layout for the new text is built, and register for icons
      // that load later. Runs from the TextView constructor too: use nothing initialized after it.
      val contentWidth = width - compoundPaddingLeft - compoundPaddingRight
      if (contentWidth > 0) prepareWidthAwareSpans(text, contentWidth)
      LinkPillSpan.registerView(text, this)
      val heuristicChanged = markdownTextDirection?.update(writingDirection, text) == true
      super.setText(text, type)
      if (heuristicChanged) onRtlPropertiesChanged(layoutDirection)
    }

    override fun onDraw(canvas: Canvas) {
      InlineBackgroundGeometry.drawWith(layout) { super.onDraw(canvas) }
    }

    override fun onMeasure(
      widthMeasureSpec: Int,
      heightMeasureSpec: Int,
    ) {
      if (MeasureSpec.getMode(widthMeasureSpec) != MeasureSpec.UNSPECIFIED) {
        val width = (MeasureSpec.getSize(widthMeasureSpec) - compoundPaddingLeft - compoundPaddingRight).coerceAtLeast(1)
        // TextView keeps its layout when the new width still fits the old lines.
        if (prepareWidthAwareSpans(text, width) && layout != null) dropTextLayout()
      }
      super.onMeasure(widthMeasureSpec, heightMeasureSpec)
    }

    /**
     * Makes the next measure build a fresh text layout. TextView exposes no direct way:
     * re-setting the text would copy it and clear the selection, while setting the break
     * strategy, even to its current value, discards the layout and nothing else.
     */
    private fun dropTextLayout() {
      breakStrategy = breakStrategy
    }

    override fun dispatchHoverEvent(event: MotionEvent): Boolean =
      accessibilityHelper.dispatchHoverEvent(event) || super.dispatchHoverEvent(event)

    override fun dispatchKeyEvent(event: KeyEvent): Boolean = accessibilityHelper.dispatchKeyEvent(event) || super.dispatchKeyEvent(event)

    override fun onFocusChanged(
      gainFocus: Boolean,
      direction: Int,
      previouslyFocusedRect: Rect?,
    ) {
      super.onFocusChanged(gainFocus, direction, previouslyFocusedRect)
      accessibilityHelper.onFocusChanged(gainFocus, direction, previouslyFocusedRect)
    }

    override fun onDetachedFromWindow() {
      // Before super, and here rather than in a ViewManager's
      // onDropViewInstance: getViewTreeObserver() returns the WINDOW's observer
      // only while the view is attached. Once detached it hands back the view's
      // own floating observer, so a removal then would target the wrong
      // observer and leave the listener on the window.
      accessibilityHelper.cleanup()
      super.onDetachedFromWindow()
    }
  }
