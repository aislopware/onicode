package com.swmansion.enriched.markdown.spans

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.text.Spannable
import android.text.Spanned
import android.text.style.LeadingMarginSpan
import android.util.Log
import android.widget.TextView
import androidx.core.graphics.createBitmap
import androidx.core.graphics.drawable.toDrawable
import androidx.core.graphics.withClip
import androidx.core.graphics.withSave
import com.swmansion.enriched.markdown.EnrichedMarkdownText
import com.swmansion.enriched.markdown.styles.ImageSourceOverride
import com.swmansion.enriched.markdown.styles.StyleConfig
import com.swmansion.enriched.markdown.utils.common.findEnrichedMarkdownAncestor
import com.swmansion.enriched.markdown.utils.text.ImageCache
import com.swmansion.enriched.markdown.utils.text.ImageDownloader
import com.swmansion.enriched.markdown.utils.text.LocalImageLoader
import com.swmansion.enriched.markdown.utils.text.view.repaintSpan
import java.lang.ref.WeakReference
import java.util.concurrent.Executors
import kotlin.math.ceil
import kotlin.math.floor
import android.text.style.ImageSpan as AndroidImageSpan
import android.text.style.LineHeightSpan as AndroidLineHeightSpan

class ImageSpan(
  private val context: Context,
  val imageUrl: String,
  styleConfig: StyleConfig,
  val isInline: Boolean = false,
  val altText: String = "",
  // `resolveImageSource` result for this occurrence; imageUrl stays the Markdown
  // URL for press, copy and alt text, this decides what is requested.
  private val sourceOverride: ImageSourceOverride? = null,
) : AndroidImageSpan(
    Color.TRANSPARENT.toDrawable(),
    imageUrl,
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) ALIGN_CENTER else ALIGN_BASELINE,
  ),
  AndroidLineHeightSpan {
  private var loadedDrawable: Drawable? = null
  private val height: Int = if (isInline) styleConfig.inlineImageStyle.size.toInt() else styleConfig.imageStyle.height.toInt()

  private val borderRadiusPx: Int = styleConfig.imageStyle.borderRadius.toInt()
  private val maxHeightPx: Int = if (isInline) 0 else styleConfig.imageStyle.maxHeight.toInt()
  private val aspectRatio: Float = if (isInline) 0f else styleConfig.imageStyle.aspectRatio
  private val resizeMode: String = if (isInline) "" else styleConfig.imageStyle.resizeMode

  // so legacy always implies a fixed height box.
  private val legacySizing: Boolean = resizeMode.isEmpty()

  private val dynamicBoxHeight: Boolean = !isInline && (maxHeightPx > 0 || aspectRatio > 0f)

  private var boxHeight: Int =
    when {
      isInline -> height
      maxHeightPx > 0 -> maxHeightPx
      else -> height
    }
  private val placeholderBoxHeight: Int = boxHeight

  private val requestUrl: String = sourceOverride?.uri ?: imageUrl
  private val requestHeaders: Map<String, String> =
    if (sourceOverride == null) {
      styleConfig.imageRequestHeaders
    } else {
      ImageCache.normalizedHeaders(styleConfig.imageRequestHeaders) + sourceOverride.headers
    }
  private val requestKey: String = ImageCache.requestKey(requestUrl, requestHeaders)

  private var loadFailed: Boolean = ImageCache.hasFailed(requestKey)

  // Read now: `paragraphStyle` is only the table cell's style while the cell is being rendered.
  private val failureColor: Int = styleConfig.paragraphStyle.color
  private val failureFontSize: Float = styleConfig.paragraphStyle.fontSize
  private val failureDrawable by lazy {
    ImageLoadFailureDrawable(
      altText = altText,
      color = failureColor,
      fontSize = failureFontSize,
      borderRadius = borderRadiusPx.toFloat(),
      isInline = isInline,
      density = context.resources.displayMetrics.density,
    )
  }

  private var cachedWidth: Int = 0
  private var lineAfterImage: Int = -1
  private var addedLineHeight: Int = 0
  private val capBounds = Rect()
  private var viewRef: WeakReference<TextView>? = null
  private var sourceDrawable: Drawable? = null
  private var onBoxHeightChanged: (() -> Unit)? = null
  private var boxHeightReported = false

  private fun intrinsicImageSize(): Pair<Int, Int> {
    sourceDrawable?.let { return it.intrinsicWidth to it.intrinsicHeight }
    val cached = ImageCache.getOriginal(requestKey) ?: return 0 to 0
    return cached.width to cached.height
  }

  // Sizing precedence: aspectRatio > maxHeight > height. Returns the legacy fixed
  // height when no new knob is set.
  private fun resolveBoxHeight(targetWidth: Int): Int {
    if (isInline) return height
    if (aspectRatio > 0f && targetWidth > 0) {
      return (targetWidth / aspectRatio).toInt().coerceAtLeast(1)
    }
    if (maxHeightPx > 0) {
      val (intrinsicWidth, intrinsicHeight) = intrinsicImageSize()
      if (targetWidth > 0 && intrinsicWidth > 0 && intrinsicHeight > 0) {
        val fitted = targetWidth.toFloat() * intrinsicHeight / intrinsicWidth
        return minOf(maxHeightPx.toFloat(), fitted).toInt().coerceAtLeast(1)
      }
      return maxHeightPx
    }
    return height
  }

  /** Sizes the image for a layout about to be built over [text]; returns true when its size changed. */
  fun prepareForMeasurement(
    text: Spanned,
    widthPx: Int,
  ): Boolean {
    if (widthPx <= 0) return false
    val available = availableWidthIn(text, widthPx)
    if (isInline) {
      // Only a failure chip depends on the width: it is no wider than its line.
      val previousWidth = getDrawable().bounds.right
      cachedWidth = available
      return getDrawable().bounds.right != previousWidth
    }
    if (available <= 0) return false
    // The height can change at the same width: a download caches the image before its callback runs.
    val fittedHeight = if (dynamicBoxHeight) resolveBoxHeight(available) else boxHeight
    val changed = available != cachedWidth || fittedHeight != boxHeight
    cachedWidth = available
    boxHeight = fittedHeight
    if (changed) assignLoadedDrawable(available)
    return changed
  }

  init {
    loadImage()
  }

  private fun loadImage() {
    // A pending or rejected resolution keeps the placeholder and requests nothing.
    if (requestUrl.isEmpty()) return
    val scheme = Uri.parse(requestUrl).scheme?.lowercase()
    if (scheme == "http" || scheme == "https") {
      ImageDownloader.download(context, requestUrl, requestHeaders, ::handleLoadResult)
    } else {
      val cached = ImageCache.getOriginal(requestKey)
      val bitmap = cached ?: LocalImageLoader.load(context, requestUrl)
      if (bitmap != null && cached == null) ImageCache.putOriginal(requestKey, bitmap)
      handleLoadResult(bitmap)
    }
  }

  private fun handleLoadResult(bitmap: Bitmap?) {
    val wasFailed = loadFailed
    // Read before the state changes: a failure chip is wider than the square it replaces.
    val previousSize = currentSize()
    if (bitmap == null) {
      ImageCache.markFailed(requestKey)
      loadFailed = true
      if (!wasFailed) refreshForSize(previousSize)
      return
    }
    ImageCache.clearFailed(requestKey)
    loadFailed = false
    sourceDrawable = bitmap.toDrawable(context.resources)
    wrapAndAssignDrawable(previousSize)
  }

  private fun wrapAndAssignDrawable(placeholderSize: Pair<Int, Int>) {
    val targetWidth =
      if (isInline) {
        height
      } else {
        // A view that has no size yet keeps the width the image was prepared with.
        cachedWidth = viewRef?.get()?.let { getAvailableWidth(it) }?.takeIf { it > 0 } ?: cachedWidth
        cachedWidth
      }
    assignLoadedDrawable(targetWidth)
    refreshForSize(placeholderSize)
  }

  // Laying out a paragraph measures all of its images, so one that fills the box its
  // placeholder held only repaints. Otherwise a paragraph of N images is quadratic in N.
  private fun refreshForSize(previousSize: Pair<Int, Int>) {
    if (currentSize() == previousSize) {
      requestRepaint()
      // onMeasure may have fitted the box already, but the component's height can predate that.
      viewRef?.get()?.let { notifyBoxHeightMayHaveChanged(it) }
    } else {
      // An inline image turning into a failure chip, or back, can re-wrap its line.
      requestReflow(inlineSizeChanged = isInline)
    }
  }

  private fun currentSize(): Pair<Int, Int> = getDrawable().bounds.right to boxHeight

  private fun assignLoadedDrawable(targetWidth: Int) {
    val base = sourceDrawable ?: return
    boxHeight = resolveBoxHeight(targetWidth)

    val cachedBitmap = ImageCache.getProcessed(requestKey, targetWidth, boxHeight, borderRadiusPx, resizeMode)

    if (cachedBitmap != null) {
      loadedDrawable =
        cachedBitmap.toDrawable(context.resources).apply {
          setBounds(0, 0, targetWidth, boxHeight)
        }
    } else {
      loadedDrawable =
        ScaledImageDrawable(
          imageDrawable = base,
          targetWidth = targetWidth,
          targetHeight = boxHeight,
          borderRadius = borderRadiusPx,
          isBlockImage = !isInline,
          resizeMode = resizeMode,
          legacySizing = legacySizing,
          cacheKey = CacheKey(requestKey, targetWidth, boxHeight, borderRadiusPx, resizeMode),
        )
    }
  }

  private fun requestRepaint() {
    val view = viewRef?.get() ?: return
    (view.text as? Spannable)?.repaintSpan(this) ?: view.invalidate()
  }

  private fun requestReflow(inlineSizeChanged: Boolean = false) {
    val view = viewRef?.get() ?: return
    TextBackgroundDrawer.noteReflow()
    val text = view.text
    if (text is Spannable) {
      val start = text.getSpanStart(this)
      val end = text.getSpanEnd(this)
      if (start != -1 && end != -1) {
        text.setSpan(this, start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
      }
    }
    view.invalidate()
    view.requestLayout()
    notifyBoxHeightMayHaveChanged(view, inlineSizeChanged)
  }

  // With maxHeight/aspectRatio the box height can change after the image loads
  // (maxHeight fitted, aspectRatio at a late width). The React container height
  // was measured with the pre-load value, so ask the owning component to
  // re-measure; it only propagates when the stored height actually changed.
  // An inline image turning into a failure chip (or back) can re-wrap its line.
  private fun notifyBoxHeightMayHaveChanged(
    view: TextView,
    inlineSizeChanged: Boolean = false,
  ) {
    if (!dynamicBoxHeight && !inlineSizeChanged) return
    boxHeightReported = true
    // A self-measuring host (e.g. a table cell) sizes the image box itself and drives
    // its own re-layout, so bubbling up to the component would churn it and orphan this
    // freshly registered view. Let the host re-measure locally instead.
    onBoxHeightChanged?.let {
      it()
      return
    }
    if (view is EnrichedMarkdownText) {
      view.layoutManager.invalidateLayout()
      return
    }
    view.findEnrichedMarkdownAncestor()?.onImageLayoutChanged()
  }

  fun registerTextView(
    view: TextView,
    onBoxHeightChanged: (() -> Unit)? = null,
  ) {
    this.onBoxHeightChanged = onBoxHeightChanged
    viewRef = WeakReference(view)
    if (!isInline) {
      val availableWidth = getAvailableWidth(view)
      if (availableWidth > 0) {
        updateWidthAndRecreate(availableWidth)
      }
      view.post {
        val postWidth = getAvailableWidth(view)
        if (postWidth != cachedWidth) updateWidthAndRecreate(postWidth)
        // onMeasure may have fitted the box without a new width to report here, and the
        // component may have measured before the image was cached. A box still at its
        // placeholder height can't have left the component stale, and a load notifies anyway.
        if (!boxHeightReported && boxHeight != placeholderBoxHeight) notifyBoxHeightMayHaveChanged(view)
      }
    }
  }

  private fun updateWidthAndRecreate(newWidth: Int) {
    if (newWidth <= 0 || cachedWidth == newWidth) return
    cachedWidth = newWidth
    if (sourceDrawable != null) {
      assignLoadedDrawable(newWidth)
    } else if (dynamicBoxHeight) {
      boxHeight = resolveBoxHeight(newWidth)
    }
    // The placeholder and a failed image's box take up the same width as the image, so the lines change here too.
    requestReflow()
  }

  private fun getAvailableWidth(view: TextView): Int {
    val baseWidth = (view.layout?.width ?: (view.width - view.compoundPaddingLeft - view.compoundPaddingRight)).coerceAtLeast(0)
    val text = view.text as? Spanned ?: return baseWidth
    return availableWidthIn(text, baseWidth)
  }

  private fun availableWidthIn(
    text: Spanned,
    baseWidth: Int,
  ): Int {
    val start = text.getSpanStart(this).takeIf { it >= 0 } ?: return baseWidth
    val end = text.getSpanEnd(this).coerceAtLeast(start)
    // Subtract leading margins (list bullet/indent, blockquote bar) that consume
    // horizontal space on the image's line. first=true is correct because a block
    // image sits on its own line — the "first line" from the layout's perspective.
    val totalMargin =
      text
        .getSpans(start, end, LeadingMarginSpan::class.java)
        .sumOf { it.getLeadingMargin(true) }
    return (baseWidth - totalMargin).coerceAtLeast(0)
  }

  override fun getDrawable(): Drawable {
    if (loadFailed) {
      // An inline image's cachedWidth is its line's width after leading margins.
      val width = if (isInline) failureDrawable.chipWidth(height, cachedWidth) else cachedWidth
      failureDrawable.setBounds(0, 0, width.coerceAtLeast(0), boxHeight.coerceAtLeast(0))
      return failureDrawable
    }
    val drawable = loadedDrawable ?: transparentDrawable
    if (drawable !is ScaledImageDrawable) {
      val drawableWidth = if (isInline) height else cachedWidth.takeIf { it > 0 } ?: drawable.intrinsicWidth
      drawable.setBounds(0, 0, drawableWidth.coerceAtLeast(0), boxHeight.coerceAtLeast(0))
    }
    return drawable
  }

  override fun getSize(
    paint: Paint,
    text: CharSequence?,
    start: Int,
    end: Int,
    fm: Paint.FontMetricsInt?,
  ): Int {
    if (isInline && fm != null) {
      // The line grows to fit a tall image, as iOS grows it for an attachment.
      paint.getFontMetricsInt(fm)
      val imageTop = inlineImageTop(paint)
      fm.ascent = minOf(fm.ascent, floor(imageTop).toInt())
      fm.top = minOf(fm.top, fm.ascent)
      fm.descent = maxOf(fm.descent, ceil(imageTop + height).toInt())
      fm.bottom = maxOf(fm.bottom, fm.descent)
    }
    return getDrawable().bounds.right
  }

  /** The inline image's top relative to the baseline: centered on the cap height, as iOS places inline attachments. */
  private fun inlineImageTop(paint: Paint): Float {
    paint.getTextBounds("H", 0, 1, capBounds)
    return -(capBounds.height() + height) / 2f
  }

  override fun chooseHeight(
    text: CharSequence?,
    start: Int,
    end: Int,
    spanstartv: Int,
    lineHeight: Int,
    fm: Paint.FontMetricsInt?,
  ) {
    if (fm == null || isInline) return
    // Text after the image shares its paragraph, so this runs for those lines too. When a
    // text run continues past the line break, StaticLayout starts the next line from this
    // line's metrics, so the height added for the image has to come off again there. A
    // block image always opens its paragraph, so its line sets these fields first.
    if (start == lineAfterImage) {
      if (fm.descent - fm.ascent >= boxHeight) {
        fm.descent -= addedLineHeight
        fm.bottom -= addedLineHeight
      }
      return
    }
    if ((text as? Spanned)?.getSpanStart(this) !in start until end) return
    addedLineHeight = (boxHeight - (fm.descent - fm.ascent)).coerceAtLeast(0)
    fm.descent += addedLineHeight
    fm.bottom += addedLineHeight
    lineAfterImage = end
  }

  override fun draw(
    canvas: Canvas,
    text: CharSequence?,
    start: Int,
    end: Int,
    x: Float,
    top: Int,
    y: Int,
    bottom: Int,
    paint: Paint,
  ) {
    val drawable = getDrawable()
    canvas.withSave {
      if (isInline) {
        translate(x, y + inlineImageTop(paint))
      } else {
        translate(x, top.toFloat())
      }
      drawable.draw(this)
    }
  }

  private data class CacheKey(
    val url: String,
    val width: Int,
    val height: Int,
    val borderRadius: Int,
    val resizeMode: String,
  )

  private class ScaledImageDrawable(
    private val imageDrawable: Drawable,
    private val targetWidth: Int,
    private val targetHeight: Int,
    private val borderRadius: Int,
    isBlockImage: Boolean,
    private val resizeMode: String = "",
    private val legacySizing: Boolean = true,
    private val cacheKey: CacheKey? = null,
  ) : Drawable() {
    private val clipPath: Path?
    private var hasCached = false

    init {
      setBounds(0, 0, targetWidth, targetHeight)
      val intrinsicWidth = imageDrawable.intrinsicWidth
      val intrinsicHeight = imageDrawable.intrinsicHeight

      // New sizing needs a clip to the box so cropping
      // modes don't spill over neighbouring lines.
      val clipToBox = isBlockImage && !legacySizing

      val (scaledWidth, scaledHeight) =
        if (intrinsicWidth > 0 && intrinsicHeight > 0) {
          when {
            !isBlockImage -> {
              val scale = minOf(targetWidth.toFloat() / intrinsicWidth, targetHeight.toFloat() / intrinsicHeight)
              (intrinsicWidth * scale).toInt() to (intrinsicHeight * scale).toInt()
            }

            legacySizing -> {
              val scale = targetWidth.toFloat() / intrinsicWidth
              targetWidth to (intrinsicHeight * scale).toInt()
            }

            else -> {
              resizeModeSize(intrinsicWidth, intrinsicHeight)
            }
          }
        } else {
          targetWidth to targetHeight
        }

      val left = (targetWidth - scaledWidth) / 2
      val top = (targetHeight - scaledHeight) / 2
      imageDrawable.setBounds(left, top, left + scaledWidth, top + scaledHeight)

      val clipLeft = maxOf(0, left).toFloat()
      val clipTop = maxOf(0, top).toFloat()
      val clipRight = minOf(targetWidth, left + scaledWidth).toFloat()
      val clipBottom = minOf(targetHeight, top + scaledHeight).toFloat()
      clipPath =
        when {
          borderRadius > 0 -> {
            Path().apply {
              addRoundRect(
                clipLeft,
                clipTop,
                clipRight,
                clipBottom,
                borderRadius.toFloat(),
                borderRadius.toFloat(),
                Path.Direction.CW,
              )
            }
          }

          clipToBox -> {
            Path().apply {
              addRect(clipLeft, clipTop, clipRight, clipBottom, Path.Direction.CW)
            }
          }

          else -> {
            null
          }
        }
    }

    private fun resizeModeSize(
      intrinsicWidth: Int,
      intrinsicHeight: Int,
    ): Pair<Int, Int> {
      if (resizeMode == "stretch") return targetWidth to targetHeight
      val widthScale = targetWidth.toFloat() / intrinsicWidth
      val heightScale = targetHeight.toFloat() / intrinsicHeight
      val scale =
        when (resizeMode) {
          "contain" -> minOf(widthScale, heightScale)
          "center" -> minOf(1f, minOf(widthScale, heightScale))
          "none" -> 1f
          else -> maxOf(widthScale, heightScale) // cover (default)
        }
      return (intrinsicWidth * scale).toInt() to (intrinsicHeight * scale).toInt()
    }

    override fun draw(canvas: Canvas) {
      if (clipPath != null) {
        canvas.withSave {
          clipPath(clipPath)
          imageDrawable.draw(canvas)
        }
      } else {
        imageDrawable.draw(canvas)
      }
      scheduleCacheBitmap()
    }

    private fun scheduleCacheBitmap() {
      if (hasCached || cacheKey == null || targetWidth <= 0 || targetHeight <= 0) return
      hasCached = true
      val cachedKey = cacheKey
      val width = targetWidth
      val height = targetHeight
      val path = clipPath
      val source = imageDrawable
      cacheExecutor.execute {
        try {
          val bitmap = createBitmap(width, height)
          val offscreen = Canvas(bitmap)
          if (path != null) {
            offscreen.withClip(path) { source.draw(this) }
          } else {
            source.draw(offscreen)
          }
          ImageCache.putProcessed(
            cachedKey.url,
            cachedKey.width,
            cachedKey.height,
            cachedKey.borderRadius,
            cachedKey.resizeMode,
            bitmap,
          )
        } catch (_: OutOfMemoryError) {
          Log.e("ScaledImageDrawable", "OOM caching bitmap ${width}x$height")
        }
      }
    }

    override fun setAlpha(alpha: Int) {
      imageDrawable.alpha = alpha
    }

    override fun setColorFilter(colorFilter: android.graphics.ColorFilter?) {
      imageDrawable.colorFilter = colorFilter
    }

    @Suppress("DEPRECATION")
    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = imageDrawable.opacity

    override fun getIntrinsicWidth(): Int = targetWidth

    override fun getIntrinsicHeight(): Int = targetHeight
  }

  companion object {
    private val transparentDrawable by lazy { Color.TRANSPARENT.toDrawable() }
    private val cacheExecutor = Executors.newSingleThreadExecutor()
  }
}
