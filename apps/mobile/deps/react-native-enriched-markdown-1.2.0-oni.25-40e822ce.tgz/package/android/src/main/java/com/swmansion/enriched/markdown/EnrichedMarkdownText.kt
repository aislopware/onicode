package com.swmansion.enriched.markdown

import android.content.Context
import android.content.res.Configuration
import android.graphics.Canvas
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.text.Layout
import android.util.AttributeSet
import android.util.Log
import android.util.TypedValue
import android.view.MotionEvent
import android.view.View
import android.view.View.MeasureSpec
import androidx.annotation.VisibleForTesting
import com.facebook.react.bridge.ReadableMap
import com.facebook.react.uimanager.BackgroundStyleApplicator
import com.facebook.react.uimanager.PixelUtil
import com.facebook.react.uimanager.StateWrapper
import com.facebook.react.uimanager.style.LogicalEdge
import com.swmansion.enriched.markdown.accessibility.AccessibilityLabels
import com.swmansion.enriched.markdown.accessibility.AccessibleMarkdownTextView
import com.swmansion.enriched.markdown.math.LatexErrorReporter
import com.swmansion.enriched.markdown.parser.MarkdownASTNode
import com.swmansion.enriched.markdown.parser.Md4cFlags
import com.swmansion.enriched.markdown.parser.Parser
import com.swmansion.enriched.markdown.renderer.Renderer
import com.swmansion.enriched.markdown.segments.RenderedSegment
import com.swmansion.enriched.markdown.segments.TextRenderCache
import com.swmansion.enriched.markdown.segments.TextRenderResult
import com.swmansion.enriched.markdown.segments.textRenderResult
import com.swmansion.enriched.markdown.spoiler.SpoilerCapable
import com.swmansion.enriched.markdown.spoiler.SpoilerOverlay
import com.swmansion.enriched.markdown.spoiler.SpoilerOverlayDrawer
import com.swmansion.enriched.markdown.styles.LinkPillContent
import com.swmansion.enriched.markdown.styles.StyleConfig
import com.swmansion.enriched.markdown.utils.common.BreakStrategyUtils
import com.swmansion.enriched.markdown.utils.common.CodeBlockStreamingMode
import com.swmansion.enriched.markdown.utils.common.EllipsizeUtils
import com.swmansion.enriched.markdown.utils.common.LinkRegexConfig
import com.swmansion.enriched.markdown.utils.common.MediaStreamingMode
import com.swmansion.enriched.markdown.utils.common.RenderCoordinator
import com.swmansion.enriched.markdown.utils.common.StreamingMarkdownFilter
import com.swmansion.enriched.markdown.utils.common.TableStreamingMode
import com.swmansion.enriched.markdown.utils.common.emitCodeBlockPress
import com.swmansion.enriched.markdown.utils.common.isReducedMotionEnabled
import com.swmansion.enriched.markdown.utils.common.layout.allowsTextPatches
import com.swmansion.enriched.markdown.utils.text.StreamingEffects
import com.swmansion.enriched.markdown.utils.text.StreamingEffectsAnimator
import com.swmansion.enriched.markdown.utils.text.StreamingPacer
import com.swmansion.enriched.markdown.utils.text.interaction.CheckboxTouchHelper
import com.swmansion.enriched.markdown.utils.text.view.CodeBlockPressHost
import com.swmansion.enriched.markdown.utils.text.view.ImagePressHost
import com.swmansion.enriched.markdown.utils.text.view.LinkLongPressMovementMethod
import com.swmansion.enriched.markdown.utils.text.view.SelectionMenuConfig
import com.swmansion.enriched.markdown.utils.text.view.TextPressHost
import com.swmansion.enriched.markdown.utils.text.view.applySelectableState
import com.swmansion.enriched.markdown.utils.text.view.applySelectionColors
import com.swmansion.enriched.markdown.utils.text.view.cancelJSTouchForCheckboxTap
import com.swmansion.enriched.markdown.utils.text.view.cancelJSTouchForLinkTap
import com.swmansion.enriched.markdown.utils.text.view.createSelectionActionModeCallback
import com.swmansion.enriched.markdown.utils.text.view.emitImagePressEvent
import com.swmansion.enriched.markdown.utils.text.view.emitLinkLongPressEvent
import com.swmansion.enriched.markdown.utils.text.view.emitLinkPressEvent
import com.swmansion.enriched.markdown.utils.text.view.emitStreamingEndEvent
import com.swmansion.enriched.markdown.utils.text.view.emitTextPressEvent
import com.swmansion.enriched.markdown.utils.text.view.isAdoptedText
import com.swmansion.enriched.markdown.utils.text.view.setupAsMarkdownTextView
import java.util.concurrent.Executors
import kotlin.math.ceil
import kotlin.math.roundToInt

/**
 * EnrichedMarkdownText that handles Markdown parsing and rendering on a background thread.
 * View starts invisible and becomes visible after render completes to avoid layout shift.
 */
class EnrichedMarkdownText
  @JvmOverloads
  constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
  ) : AccessibleMarkdownTextView(context, attrs, defStyleAttr),
    SpoilerCapable,
    ImagePressHost,
    TextPressHost,
    CodeBlockPressHost {
    private val parser = Parser.shared
    private val renderer = Renderer()
    private var onLinkPressCallback: ((String) -> Unit)? = null
    private var onLinkLongPressCallback: ((String) -> Unit)? = null
    private var onLatexErrorCallback: LatexErrorReporter? = null

    private val reportedLatexErrors = HashSet<String>()

    private val latexErrorReporter =
      LatexErrorReporter { source, message, displayMode ->
        val key = (if (displayMode) "B " else "I ") + source
        if (reportedLatexErrors.add(key)) {
          onLatexErrorCallback?.report(source, message, displayMode)
        }
      }
    private val checkboxTouchHelper = CheckboxTouchHelper(this)

    private val mainHandler = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()
    private val renderCoordinator = RenderCoordinator(executor) { mainHandler.post(it) }

    val layoutManager = EnrichedMarkdownTextLayoutManager(this)

    // used to force a Yoga re-measure when a block image resolves its box height
    var stateWrapper: StateWrapper? = null

    private var contextMenuItemTexts: List<String> = emptyList()
    var onContextMenuItemPressCallback: ((itemText: String, selectedText: String, selectionStart: Int, selectionEnd: Int) -> Unit)? = null

    var selectionClipboardConfig =
      com.swmansion.enriched.markdown.utils.text.view
        .SelectionClipboardConfig()
      private set

    fun setSelectionClipboardConfig(value: String?) {
      selectionClipboardConfig =
        com.swmansion.enriched.markdown.utils.text.view.SelectionClipboardConfig
          .parse(value)
      markdownStyle?.selectionClipboard = selectionClipboardConfig
    }

    var markdownStyle: StyleConfig? = null
      private set

    var currentMarkdown: String = ""
      private set

    var md4cFlags: Md4cFlags = Md4cFlags.DEFAULT
      private set
    private var linkRegex: LinkRegexConfig? = null
    private var inlineCodeLinkRegex: LinkRegexConfig? = null
    private var isGFM: Boolean = false

    private var lastKnownFontScale: Float = context.resources.configuration.fontScale
    private var markdownStyleMap: ReadableMap? = null

    private var allowFontScaling: Boolean = true
    private var maxFontSizeMultiplier: Float = 0f
    private var allowTrailingMargin: Boolean = false
    private var imageRequestHeaders: Map<String, String> = emptyMap()
    private var linkPillContent: Map<String, LinkPillContent> = emptyMap()

    // Whether the view streams: after the prop turns off, smooth pacing keeps it on until the words
    // still waiting have appeared.
    var isStreaming: Boolean = false
      private set
    private var streamingProp = false

    // The stream ended and onStreamingEnd waits for the render that shows the whole text.
    private var streamEndPending = false
    private var pacingChanged = false

    // streamingConfig.smooth: the view renders the markdown [pacer] has revealed so far.
    private var smooth = false
    private val pacer =
      StreamingPacer(
        reveal = {
          renderedSource = it
          scheduleRender()
        },
        done = { stopStreaming() },
      )

    // The markdown renders take: all of [currentMarkdown], or what smooth pacing has revealed.
    private var renderedSource = ""

    val isJustified: Boolean get() = markdownStyle?.needsJustify == true
    private var tableStreamingMode = TableStreamingMode.PROGRESSIVE
    private var codeBlockStreamingMode = CodeBlockStreamingMode.PROGRESSIVE
    private var mediaStreamingMode = MediaStreamingMode.PROGRESSIVE
    private var previousTextLength: Int = 0

    private var streamEnding = false
    private var effectsConfig = StreamingEffects.Config()
    private var effectsAnimator: StreamingEffectsAnimator? = null
    override var spoilerOverlayDrawer: SpoilerOverlayDrawer? = null
      private set
    var spoilerOverlay: SpoilerOverlay = SpoilerOverlay.PARTICLES

    private var pendingText: RenderedSegment.Text? = null
    private var pendingRenderedMarkdown = ""

    // Reused by the next render on the executor (see TextRenderCache). Every input but the
    // markdown bumps the key, which drops it.
    private val textRenderCache = TextRenderCache()

    @VisibleForTesting
    internal var textRenderKey = 0L
      private set

    // The revision of the text shown (see RenderedSegment.Text.revision), and its trailing margin.
    private var renderedRevision = 0L
    private var renderedLastElementMarginBottom = 0f

    // The markdown the displayed text was rendered from, behind the prop while a render is in flight.
    internal var renderedMarkdown = ""
      private set

    private var mdNumberOfLines: Int = 0
    private var mdEllipsizeMode: String = EllipsizeUtils.DEFAULT_MODE
    private var mdSelectable: Boolean = true

    private var selectionColor: Int? = null
    private var selectionHandleColor: Int? = null
    private var selectionMenuConfig = SelectionMenuConfig()
    private var baseHorizontalPaddingLeft = 0
    private var baseHorizontalPaddingRight = 0
    private var applyingContentBoxInset = false

    init {
      setupAsMarkdownTextView()
      customSelectionActionModeCallback =
        createSelectionActionModeCallback(
          this,
          getCustomItemTexts = { contextMenuItemTexts },
          getSelectionMenuConfig = { selectionMenuConfig },
          onCustomItemPress = { itemText, selectedText, start, end ->
            onContextMenuItemPressCallback?.invoke(itemText, selectedText, start, end)
          },
          onSelectionCopy = { text, format, start, end ->
            onSelectionCopyCallback?.invoke(text, format, start, end)
          },
        )
    }

    fun setMarkdownContent(markdown: String) {
      if (currentMarkdown == markdown) return
      currentMarkdown = markdown
      pacingChanged = true
    }

    fun setMarkdownStyle(style: ReadableMap?) {
      markdownStyleMap = style
      // Register font scaling settings when style is set (view should have ID by now)
      updateMeasurementStoreFontScaling()
      val newStyle = style?.let { StyleConfig(it, context, allowFontScaling, maxFontSizeMultiplier) }
      newStyle?.selectionClipboard = selectionClipboardConfig
      newStyle?.imageRequestHeaders = imageRequestHeaders
      newStyle?.linkPillContent = linkPillContent
      if (markdownStyle == newStyle) return
      markdownStyle = newStyle
      updateJustificationMode(newStyle)
      textRenderKey++
      scheduleRender()
    }

    fun setImageRequestHeaders(headers: Map<String, String>) {
      if (imageRequestHeaders == headers) return
      imageRequestHeaders = headers
      markdownStyle?.imageRequestHeaders = headers
      scheduleRenderIfNeeded()
    }

    fun setLinkPillContent(content: Map<String, LinkPillContent>) {
      if (linkPillContent == content) return
      linkPillContent = content
      markdownStyle?.linkPillContent = content
      scheduleRenderIfNeeded()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
      super.onConfigurationChanged(newConfig)

      if (!allowFontScaling) {
        return
      }

      val newFontScale = newConfig.fontScale
      if (newFontScale != lastKnownFontScale) {
        lastKnownFontScale = newFontScale
        recreateStyleConfig()
        scheduleRenderIfNeeded()
      }
    }

    fun setLinkRegex(config: LinkRegexConfig?) {
      if (linkRegex == config) return
      linkRegex = config
      scheduleRenderIfNeeded()
    }

    fun setInlineCodeLinkRegex(config: LinkRegexConfig?) {
      if (inlineCodeLinkRegex == config) return
      inlineCodeLinkRegex = config
      scheduleRenderIfNeeded()
    }

    fun setMd4cFlags(flags: Md4cFlags) {
      if (md4cFlags == flags) return
      md4cFlags = flags
      scheduleRenderIfNeeded()
    }

    fun setIsGFM(value: Boolean) {
      if (isGFM == value) return
      isGFM = value
      scheduleRenderIfNeeded()
    }

    fun setAllowFontScaling(allow: Boolean) {
      if (allowFontScaling == allow) return
      allowFontScaling = allow
      updateMeasurementStoreFontScaling()
      recreateStyleConfig()
      scheduleRenderIfNeeded()
    }

    fun setMaxFontSizeMultiplier(multiplier: Float) {
      if (maxFontSizeMultiplier == multiplier) return
      maxFontSizeMultiplier = multiplier
      updateMeasurementStoreFontScaling()
      recreateStyleConfig()
      scheduleRenderIfNeeded()
    }

    fun setAllowTrailingMargin(allow: Boolean) {
      if (allowTrailingMargin == allow) return
      allowTrailingMargin = allow
      scheduleRenderIfNeeded()
    }

    fun setStreaming(enabled: Boolean) {
      if (streamingProp == enabled) return
      streamingProp = enabled
      pacingChanged = true
      if (enabled) {
        // A new stream: the one before it has ended, whether or not its last words drained or its
        // final render applied.
        if (isStreaming) streamEndPending = true
        emitStreamingEndIfPending()
        isStreaming = true
        streamEnding = false
        previousTextLength = text?.length ?: 0
        // The streaming session decides what renders, so the text renders again.
        scheduleRenderIfNeeded()
      }
    }

    fun setSmooth(enabled: Boolean) {
      if (smooth == enabled) return
      smooth = enabled
      pacingChanged = true
    }

    // The stream ended: the next render shows the whole text, and what still animates settles.
    private fun stopStreaming() {
      isStreaming = false
      streamEnding = true
      streamEndPending = true
      effectsAnimator?.finish()
      renderedSource = currentMarkdown
      scheduleRenderIfNeeded()
    }

    // After the first render scheduled once the stream ended: the last words are on screen.
    private fun emitStreamingEndIfPending() {
      if (!streamEndPending) return
      streamEndPending = false
      emitStreamingEndEvent()
    }

    fun setStreamingModes(
      tableMode: TableStreamingMode,
      codeBlockMode: CodeBlockStreamingMode,
      mediaMode: MediaStreamingMode,
    ) {
      if (tableMode == tableStreamingMode && codeBlockMode == codeBlockStreamingMode && mediaMode == mediaStreamingMode) return
      tableStreamingMode = tableMode
      codeBlockStreamingMode = codeBlockMode
      mediaStreamingMode = mediaMode
      if (isStreaming) scheduleRenderIfNeeded()
    }

    fun setStreamingAnimation(config: StreamingEffects.Config) {
      if (config == effectsConfig) return
      effectsConfig = config
      effectsAnimator?.configure(config)
    }

    fun commitProps() {
      updateMeasurementStoreFontScaling()
      if (!pacingChanged) return
      pacingChanged = false
      // Smooth pacing renders what has been revealed and hands the rest over frame by frame, so new
      // markdown that reveals nothing yet renders nothing. When the prop turns off, the words still
      // waiting drain first, then streaming stops.
      if (pacer.update(currentMarkdown, streamingProp, smooth)) {
        stopStreaming()
        return
      }
      val source = pacer.markdownToRender
      if (source == renderedSource) return
      renderedSource = source
      scheduleRender()
    }

    private fun updateMeasurementStoreFontScaling() {
      MeasurementStore.updateFontScalingSettings(id, allowFontScaling, maxFontSizeMultiplier)
    }

    // With nothing to render, scheduleRender still ends a stream that has ended.
    private fun scheduleRenderIfNeeded() {
      textRenderKey++
      scheduleRender()
    }

    private fun recreateStyleConfig() {
      markdownStyleMap?.let { styleMap ->
        markdownStyle =
          StyleConfig(styleMap, context, allowFontScaling, maxFontSizeMultiplier).also {
            it.selectionClipboard = selectionClipboardConfig
            it.imageRequestHeaders = imageRequestHeaders
            it.linkPillContent = linkPillContent
          }
        updateJustificationMode(markdownStyle)
      }
    }

    private fun updateJustificationMode(style: StyleConfig?) {
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        justificationMode =
          if (style?.needsJustify == true) {
            Layout.JUSTIFICATION_MODE_INTER_WORD
          } else {
            Layout.JUSTIFICATION_MODE_NONE
          }
      }
    }

    private fun scheduleRender() {
      val style = markdownStyle
      val markdown = renderedSource
      if (style == null || markdown.isEmpty()) {
        // Nothing to render: nothing is left to show either.
        if (!isStreaming) emitStreamingEndIfPending()
        return
      }

      val textLinkRegex = linkRegex
      val codeLinkRegex = inlineCodeLinkRegex
      val flags = md4cFlags
      val streaming = isStreaming
      val tableMode = tableStreamingMode
      val codeBlockMode = codeBlockStreamingMode
      val mediaMode = mediaStreamingMode
      val renderKey = textRenderKey
      // A view that copies its text (a line limit) refuses patches, so it renders in full.
      val patchable =
        mdNumberOfLines == 0 &&
          (text.isNullOrEmpty() || isAdoptedText(text)) &&
          writingDirection.allowsTextPatches(markdown, layoutDirection == LAYOUT_DIRECTION_RTL)

      renderCoordinator.schedule {
        val apply =
          run render@{
            try {
              val filtered =
                if (streaming) {
                  StreamingMarkdownFilter.renderableMarkdownForStreaming(
                    markdown,
                    flags,
                    tableMode,
                    codeBlockMode,
                    mediaMode,
                    tables = isGFM,
                  )
                } else {
                  null
                }
              val renderableMarkdown = filtered?.markdown ?: markdown
              val showsOnlyFinishedBlocks = filtered?.showsOnlyFinishedBlocks ?: false
              val ast =
                parser.parseMarkdown(renderableMarkdown, flags, isGFM, textLinkRegex, codeLinkRegex)
                  ?: return@render Runnable { if (isAttachedToWindow) clearText() }

              renderer.configure(style, context, latexErrorReporter)
              val rendered =
                if (patchable) {
                  textRenderCache.begin(renderKey)
                  val (segment, _) =
                    textRenderCache.render(ast.children, startingTaskIndex = 0, isLast = true) { nodes, taskIndex ->
                      renderText(nodes, taskIndex, style)
                    }
                  textRenderCache.end()
                  segment
                } else {
                  textRenderCache.clear()
                  TextRenderCache.segmentOf(ast.children, renderText(ast.children, 0, style), startingTaskIndex = 0)
                }

              Runnable {
                if (isAttachedToWindow) {
                  applyRenderedText(rendered, markdown)
                  // Everything shown is finished, the next block still held back: the gradient's tail
                  // settles instead of waiting for it.
                  if (showsOnlyFinishedBlocks) effectsAnimator?.takeIf { it.type == StreamingEffects.Type.GRADIENT }?.finish()
                } else {
                  pendingText = rendered
                  pendingRenderedMarkdown = markdown
                  // Parked, the view lays nothing out: measurement must not take the size it had.
                  MeasurementStore.clearLaidOutSize(id)
                }
              }
            } catch (e: Exception) {
              textRenderCache.clear()
              Log.e(TAG, "Render failed: ${e.message}", e)
              Runnable { if (isAttachedToWindow) clearText() }
            }
          }
        // The first render scheduled once the stream ended shows its last words.
        Runnable {
          val key = textRenderKey
          apply.run()
          // A patch the view can't take renders again in full (a new key): that render shows the end.
          if (!streaming && textRenderKey == key) emitStreamingEndIfPending()
        }
      }
    }

    private fun renderText(
      nodes: List<MarkdownASTNode>,
      startingTaskIndex: Int,
      style: StyleConfig,
    ): TextRenderResult {
      val styledText = renderer.renderContent(nodes, onLinkPressCallback, onLinkLongPressCallback, startingTaskIndex = startingTaskIndex)
      return renderer.textRenderResult(styledText, style.needsJustify)
    }

    // For a patch to text this view doesn't show (it was detached for a render).
    private fun renderInFull() {
      textRenderKey++
      scheduleRender()
    }

    private fun clearText() {
      text = ""
      renderedRevision = 0L
    }

    private fun applyRenderedText(
      rendered: RenderedSegment.Text,
      markdown: String,
    ) {
      // The cache handed back the segment this view shows.
      if (rendered.revision == renderedRevision) {
        renderedMarkdown = markdown
        // The stream ended on text this view already shows.
        if (streamEnding) {
          previousTextLength = 0
          streamEnding = false
        }
        return
      }
      // A patch applies only to the text it was made against.
      val patch = rendered.patch?.takeIf { it.baseRevision == renderedRevision }
      if (patch == null && rendered.styledText == null) {
        renderInFull()
        return
      }

      markdownStyle?.paragraphStyle?.fontSize?.let {
        setTextSize(TypedValue.COMPLEX_UNIT_PX, it)
      }

      var changedFrom = 0
      if (patch != null && replaceTextTail(patch.start, patch.tail)) {
        patch.tailImageSpans.forEach { it.registerTextView(this) }
        changedFrom = patch.start
      } else {
        text = rendered.styledText ?: return renderInFull()
        rendered.imageSpans.forEach { it.registerTextView(this) }
        accessibilityHelper.invalidateAccessibilityItems()
      }
      val tailStart = previousTextLength
      renderedMarkdown = markdown
      renderedRevision = rendered.revision
      renderedLastElementMarginBottom = rendered.lastElementMarginBottom
      val styledText = text

      applyInteractivity()

      spoilerOverlayDrawer = SpoilerOverlayDrawer.setupIfNeeded(this, styledText, spoilerOverlayDrawer, spoilerOverlay)

      layoutManager.invalidateLayout(changedFrom)

      if (isStreaming || streamEnding) {
        // Made once something animates; one made already started over with 'none'.
        if (effectsAnimator == null && effectsConfig.type != StreamingEffects.Type.NONE && !isReducedMotionEnabled(context)) {
          effectsAnimator = StreamingEffectsAnimator(this).also { it.configure(effectsConfig) }
        }
        effectsAnimator?.let {
          it.noteArrival(tailStart, styledText.length)
          if (streamEnding) it.finish()
        }
        previousTextLength = if (isStreaming) styledText.length else 0
        streamEnding = false
      }

      applySelectionColors(selectionColor, selectionHandleColor)
    }

    // Trailing bottom margin included in the shadow-node measurement — must be
    // mirrored when re-storing the measurement from the display text.
    fun trailingMarginBottomPx(): Float = if (allowTrailingMargin) renderedLastElementMarginBottom else 0f

    fun setContextMenuItems(items: List<String>) {
      contextMenuItemTexts = items
    }

    fun setSelectionMenuConfig(config: SelectionMenuConfig) {
      if (selectionMenuConfig == config) return
      selectionMenuConfig = config
    }

    fun setAccessibilityLabels(labels: AccessibilityLabels) {
      accessibilityHelper.labels = labels
    }

    fun setIsSelectable(selectable: Boolean) {
      mdSelectable = selectable
      applyInteractivity()
    }

    fun setSelectionColor(color: Int?) {
      if (selectionColor == color) return
      selectionColor = color
      applySelectionColors(selectionColor, selectionHandleColor)
    }

    fun setSelectionHandleColor(color: Int?) {
      if (selectionHandleColor == color) return
      selectionHandleColor = color
      applySelectionColors(selectionColor, selectionHandleColor)
    }

    fun setTextBreakStrategy(strategy: String) {
      MeasurementStore.updateBreakStrategy(id, strategy)
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        breakStrategy = BreakStrategyUtils.resolveBreakStrategy(strategy)
      }
      MeasurementStore.invalidate(id)
      scheduleRenderIfNeeded()
    }

    fun setMarkdownNumberOfLines(value: Int) {
      val normalized = value.coerceAtLeast(0)
      if (mdNumberOfLines == normalized) return
      mdNumberOfLines = normalized
      MeasurementStore.updateNumberOfLines(id, normalized)
      applyLineLimitToView()
      MeasurementStore.invalidate(id)
      scheduleRenderIfNeeded()
    }

    fun setMarkdownEllipsizeMode(value: String) {
      if (mdEllipsizeMode == value) return
      mdEllipsizeMode = value
      MeasurementStore.updateEllipsizeMode(id, value)
      applyLineLimitToView()
      MeasurementStore.invalidate(id)
      scheduleRenderIfNeeded()
    }

    // Mirrors RN's ReactTextView.updateView: only ellipsize when a line limit is
    // set; unlimited restores the default unbounded, non-ellipsized state.
    private fun applyLineLimitToView() {
      if (mdNumberOfLines > 0) {
        maxLines = mdNumberOfLines
        ellipsize = EllipsizeUtils.resolveTruncateAt(mdEllipsizeMode)
      } else {
        maxLines = Integer.MAX_VALUE
        ellipsize = null
      }
      applyInteractivity()
    }

    // The numberOfLines ellipsis and text selection / link taps are mutually
    // exclusive on Android and cannot be reconciled. Both setTextIsSelectable(true)
    // and a non-null movementMethod force the display text to a Spannable, which
    // makes TextView pick DynamicLayout (TextView.useDynamicLayout). DynamicLayout
    // has no setMaxLines, so the clamp is never baked into the layout and no
    // ellipsis glyph is drawn (verified against AOSP TextView/DynamicLayout on
    // API 35/36). To keep the ellipsis, a clamped view must be non-selectable AND
    // drop its movement method; both are restored to the user's preference once
    // the clamp is removed.
    private fun applyInteractivity() {
      if (mdNumberOfLines > 0) {
        if (isTextSelectable) setTextIsSelectable(false)
        movementMethod = null
      } else {
        applySelectableState(mdSelectable)
        if (movementMethod !is LinkLongPressMovementMethod) {
          movementMethod = LinkLongPressMovementMethod.createInstance()
        }
      }
    }

    fun emitOnLinkPress(url: String) {
      emitLinkPressEvent(url)
    }

    fun emitOnLinkLongPress(url: String) {
      emitLinkLongPressEvent(url)
    }

    override var imagePressEnabled: Boolean = false
      private set

    override fun emitOnImagePress(
      url: String,
      altText: String,
    ) {
      emitImagePressEvent(url, altText)
    }

    fun setEnableImagePress(enabled: Boolean) {
      imagePressEnabled = enabled
    }

    override var textPressEnabled: Boolean = false
      private set

    override fun emitOnTextPress(
      index: Int,
      text: String,
    ) {
      emitTextPressEvent(index, text)
    }

    fun setEnableTextPress(enabled: Boolean) {
      textPressEnabled = enabled
    }

    override var codeBlockPressEnabled: Boolean = false
      private set

    override fun emitOnCodeBlockPress(
      code: String,
      language: String,
    ) {
      emitCodeBlockPress(this, code, language)
    }

    fun setEnableCodeBlockPress(enabled: Boolean) {
      codeBlockPressEnabled = enabled
    }

    fun setOnLinkPressCallback(callback: (String) -> Unit) {
      onLinkPressCallback = callback
    }

    fun setOnLinkLongPressCallback(callback: (String) -> Unit) {
      onLinkLongPressCallback = callback
    }

    fun setOnLatexErrorCallback(callback: LatexErrorReporter) {
      onLatexErrorCallback = callback
    }

    fun setOnTaskListItemPressCallback(callback: ((taskIndex: Int, checked: Boolean, itemText: String) -> Unit)?) {
      checkboxTouchHelper.onCheckboxTap = callback
    }

    fun setEnableTaskListItemToggle(enabled: Boolean) {
      checkboxTouchHelper.isEnabled = enabled
    }

    fun cleanup() {
      renderCoordinator.invalidate()
      executor.shutdownNow()
      mainHandler.removeCallbacksAndMessages(null)
      pendingText = null
      pendingRenderedMarkdown = ""
      effectsAnimator?.release()
      effectsAnimator = null
      pacer.release()
    }

    override fun setPadding(
      left: Int,
      top: Int,
      right: Int,
      bottom: Int,
    ) {
      if (!applyingContentBoxInset) {
        baseHorizontalPaddingLeft = left
        baseHorizontalPaddingRight = right
      }
      super.setPadding(left, top, right, bottom)
    }

    override fun onMeasure(
      widthMeasureSpec: Int,
      heightMeasureSpec: Int,
    ) {
      applyContentBoxInset(widthMeasureSpec)
      super.onMeasure(widthMeasureSpec, heightMeasureSpec)
    }

    /**
     * Fabric measures text at the content box (frame - padding - border) but the TextView's
     * padding carries no border, so it wraps ~1dp wider and reserves a phantom trailing line
     * under an unclamped box (#805). Fold the border into padding to match; restore the base
     * padding when the cache or an exact frame is missing so no stale inset lingers.
     */
    private fun applyContentBoxInset(widthMeasureSpec: Int) {
      val contentBox =
        if (MeasureSpec.getMode(widthMeasureSpec) == MeasureSpec.EXACTLY) {
          MeasurementStore.contentBoxWidthPx(id)?.let { ceil(it).toInt() }?.takeIf { it > 0 }
        } else {
          null
        }
      val frame = MeasureSpec.getSize(widthMeasureSpec)
      if (contentBox == null || frame <= 0) {
        setHorizontalPadding(baseHorizontalPaddingLeft, baseHorizontalPaddingRight)
        return
      }

      val totalInset = (frame - contentBox).coerceIn(0, frame)
      val left = (baseHorizontalPaddingLeft + resolvedBorderPx(leftEdge = true)).coerceIn(0, totalInset)
      val right = (totalInset - left).coerceAtLeast(0)
      setHorizontalPadding(left, right)
    }

    // Physical border width (px); only the left/right split reads it, never the total inset.
    private fun resolvedBorderPx(leftEdge: Boolean): Int {
      val rtl = layoutDirection == View.LAYOUT_DIRECTION_RTL
      val physical = if (leftEdge) LogicalEdge.LEFT else LogicalEdge.RIGHT
      val logical = if (leftEdge != rtl) LogicalEdge.START else LogicalEdge.END
      val dp =
        BackgroundStyleApplicator.getBorderWidth(this, physical)
          ?: BackgroundStyleApplicator.getBorderWidth(this, logical)
          ?: BackgroundStyleApplicator.getBorderWidth(this, LogicalEdge.ALL)
          ?: return 0
      return PixelUtil.toPixelFromDIP(dp).roundToInt().coerceAtLeast(0)
    }

    private fun setHorizontalPadding(
      left: Int,
      right: Int,
    ) {
      if (left == paddingLeft && right == paddingRight) return
      applyingContentBoxInset = true
      super.setPadding(left, paddingTop, right, paddingBottom)
      applyingContentBoxInset = false
    }

    override fun onAttachedToWindow() {
      super.onAttachedToWindow()
      pendingText?.let {
        pendingText = null
        applyRenderedText(it, pendingRenderedMarkdown)
      }
    }

    override fun onDetachedFromWindow() {
      stopSpoilerAnimations()
      // A detached view parks its renders, so a stream measures in full until it lays out again.
      MeasurementStore.clearLaidOutSize(id)
      super.onDetachedFromWindow()
    }

    // Fabric never runs a requested layout, so TextView would defer its scroll forever (#1196).
    override fun onPreDraw(): Boolean {
      if (isLayoutRequested && width > 0) {
        measure(
          MeasureSpec.makeMeasureSpec(width, MeasureSpec.EXACTLY),
          MeasureSpec.makeMeasureSpec(height, MeasureSpec.EXACTLY),
        )
        layout(left, top, right, bottom)
      }
      return super.onPreDraw()
    }

    override fun onDraw(canvas: Canvas) {
      super.onDraw(canvas)
      spoilerOverlayDrawer?.draw(canvas)
    }

    private fun stopSpoilerAnimations() {
      spoilerOverlayDrawer?.stop()
      spoilerOverlayDrawer = null
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
      if (checkboxTouchHelper.onTouchEvent(event)) {
        if (event.action == MotionEvent.ACTION_DOWN) {
          cancelJSTouchForCheckboxTap(event)
        }
        return true
      }
      val result = super.onTouchEvent(event)
      if (event.action == MotionEvent.ACTION_DOWN) cancelJSTouchForLinkTap(event)
      return result
    }

    companion object {
      private const val TAG = "EnrichedMarkdownMeasure"
    }
  }
