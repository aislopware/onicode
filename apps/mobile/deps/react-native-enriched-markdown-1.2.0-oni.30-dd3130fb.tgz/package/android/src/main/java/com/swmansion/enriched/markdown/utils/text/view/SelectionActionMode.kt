package com.swmansion.enriched.markdown.utils.text.view

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.text.Spannable
import android.text.Spanned
import android.util.Log
import android.view.ActionMode
import android.view.Menu
import android.view.MenuItem
import android.view.ViewParent
import android.widget.TextView
import com.swmansion.enriched.markdown.EnrichedMarkdown
import com.swmansion.enriched.markdown.EnrichedMarkdownText
import com.swmansion.enriched.markdown.accessibility.AccessibleMarkdownTextView
import com.swmansion.enriched.markdown.spans.ImageSpan
import com.swmansion.enriched.markdown.spans.LinkSpan
import com.swmansion.enriched.markdown.styles.StyleConfig
import com.swmansion.enriched.markdown.utils.common.layout.isLayoutRTL
import com.swmansion.enriched.markdown.utils.common.serialization.MarkdownASTSerializer
import com.swmansion.enriched.markdown.utils.text.conversion.HTMLGenerator
import com.swmansion.enriched.markdown.utils.text.conversion.MarkdownExtractor

private const val MENU_ITEM_COPY_MARKDOWN = 1000
private const val MENU_ITEM_COPY_IMAGE_URL = 1001
private const val MENU_ITEM_CUSTOM_BASE = 2000
private const val MENU_ITEM_CUSTOM_GROUP = 2001
private const val TAG = "SelectionActionMode"

data class SelectionMenuConfig(
  val copyAsMarkdown: Boolean = true,
  val copyImageUrl: Boolean = true,
  val copyLabel: String = "",
  val copyAsMarkdownLabel: String = "",
  val copyImageUrlLabel: String = "",
  val copyImageUrlsLabel: String = "",
  // Plural templates indexed by image count (0..100). Empty when no pluralLabels
  // are set; counts > 100 use copyImageUrlsLabel (the "other" form).
  val copyImageUrlPluralTemplates: List<String> = emptyList(),
)

/** What a selection copy put on the clipboard; [value] is the JS `format`. */
enum class SelectionCopyFormat(
  val value: String,
) {
  PLAIN("plain"),
  MARKDOWN("markdown"),
  IMAGE_URLS("imageUrls"),
}

/** Reports a selection copy: the copied plain text, its format, the copied range, and its Markdown whatever the format. */
typealias OnSelectionCopy = (text: String, format: SelectionCopyFormat, selectionStart: Int, selectionEnd: Int, markdown: String) -> Unit

/**
 * Resolves the "Copy Image URL(s)" menu title for the given image count. Uses the
 * precomputed plural templates when present (counts > 100 use the "other" form),
 * otherwise the singular/`{count}` templates. All labels are resolved JS-side.
 */
private fun SelectionMenuConfig.imageUrlsTitle(count: Int): String {
  val template =
    when {
      copyImageUrlPluralTemplates.isNotEmpty() && count in 0..100 -> copyImageUrlPluralTemplates[count]
      count == 1 -> copyImageUrlLabel
      else -> copyImageUrlsLabel
    }
  return template.replace("{count}", count.toString())
}

/**
 * Creates an ActionMode.Callback that adds custom copy options and
 * overrides the default "Copy" action to include HTML for rich text support.
 */
fun createSelectionActionModeCallback(
  textView: TextView,
  getCustomItemTexts: () -> List<String> = { emptyList() },
  getSelectionMenuConfig: () -> SelectionMenuConfig = { SelectionMenuConfig() },
  onCustomItemPress: (itemText: String, selectedText: String, selectionStart: Int, selectionEnd: Int) -> Unit =
    { _, _, _, _ -> },
  onSelectionCopy: OnSelectionCopy? = null,
): ActionMode.Callback =
  object : ActionMode.Callback {
    override fun onCreateActionMode(
      mode: ActionMode?,
      menu: Menu?,
    ): Boolean {
      (textView as? AccessibleMarkdownTextView)?.selectionActionMode = mode
      return true
    }

    override fun onPrepareActionMode(
      mode: ActionMode?,
      menu: Menu?,
    ): Boolean {
      if (menu == null) return false

      menu.removeItem(MENU_ITEM_COPY_MARKDOWN)
      menu.removeItem(MENU_ITEM_COPY_IMAGE_URL)
      menu.removeGroup(MENU_ITEM_CUSTOM_GROUP)

      val selectionMenuConfig = getSelectionMenuConfig()

      // The system Copy item is added by the platform; relabel it so it
      // matches the rest of the localized menu (iOS rebuilds the menu so
      // gets this for free; Android only intercepts the click).
      if (selectionMenuConfig.copyLabel.isNotEmpty()) {
        menu.findItem(android.R.id.copy)?.title = selectionMenuConfig.copyLabel
      }

      if (
        selectionMenuConfig.copyAsMarkdown &&
        textView.selectionStart >= 0 &&
        textView.selectionEnd > textView.selectionStart
      ) {
        menu.add(
          Menu.NONE,
          MENU_ITEM_COPY_MARKDOWN,
          Menu.NONE,
          selectionMenuConfig.copyAsMarkdownLabel,
        )
      }

      if (textView.selectionStart >= 0 && textView.selectionEnd > textView.selectionStart) {
        val customItems = getCustomItemTexts()
        customItems.forEachIndexed { index, text ->
          menu
            .add(MENU_ITEM_CUSTOM_GROUP, MENU_ITEM_CUSTOM_BASE + index, index, text)
            .setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS)
        }
      }

      val imageUrls =
        if (selectionMenuConfig.copyImageUrl) {
          textView.getImageUrlsInSelection()
        } else {
          emptyList()
        }
      if (imageUrls.isNotEmpty()) {
        val title = selectionMenuConfig.imageUrlsTitle(imageUrls.size)
        menu.add(Menu.NONE, MENU_ITEM_COPY_IMAGE_URL, Menu.NONE, title)
      }

      return true
    }

    override fun onActionItemClicked(
      mode: ActionMode?,
      item: MenuItem?,
    ): Boolean {
      val itemId = item?.itemId ?: return false

      // Unhandled items go to onTextContextMenuItem, which is where Copy is handled for Ctrl+C too.
      if (itemId == android.R.id.copy) return false

      val copyFormat =
        when (itemId) {
          MENU_ITEM_COPY_MARKDOWN -> SelectionCopyFormat.MARKDOWN
          MENU_ITEM_COPY_IMAGE_URL -> SelectionCopyFormat.IMAGE_URLS
          else -> null
        }
      if (copyFormat != null) {
        if (textView.copySelection(copyFormat, onSelectionCopy)) mode?.finish()
        return true
      }

      val customItems = getCustomItemTexts()
      val customIndex = itemId - MENU_ITEM_CUSTOM_BASE
      if (customIndex in customItems.indices) {
        val start = textView.selectionStart
        val end = textView.selectionEnd
        val selectedText = if (start >= 0 && end > start) textView.text.substring(start, end) else ""
        onCustomItemPress(customItems[customIndex], selectedText, start, end)
        mode?.finish()
        return true
      }

      return false
    }

    override fun onDestroyActionMode(mode: ActionMode?) {
      (textView as? AccessibleMarkdownTextView)?.selectionActionMode = null
    }
  }

/**
 * Copies the selection in [format] and reports it to [onSelectionCopy]. Shared by
 * the selection menu's copy items and `onTextContextMenuItem(android.R.id.copy)`,
 * which handles the menu's plain Copy and the keyboard shortcut.
 * Returns whether anything reached the clipboard.
 */
fun TextView.copySelection(
  format: SelectionCopyFormat,
  onSelectionCopy: OnSelectionCopy?,
): Boolean {
  // A keyboard selection made backwards has its start after its end.
  val start = minOf(selectionStart, selectionEnd)
  val end = maxOf(selectionStart, selectionEnd)
  val copied =
    when (format) {
      SelectionCopyFormat.PLAIN -> copyWithHTML(start, end)
      SelectionCopyFormat.MARKDOWN -> copyMarkdownToClipboard()
      SelectionCopyFormat.IMAGE_URLS -> copyImageUrlsToClipboard()
    } ?: return false
  if (onSelectionCopy != null) {
    val markdown = if (format == SelectionCopyFormat.MARKDOWN) copied else MarkdownExtractor.getMarkdownForSelection(this).orEmpty()
    onSelectionCopy(copied, format, start, end, markdown)
  }
  return true
}

/** The clipboard service throws on a clip over the binder limit, so a large selection can fail. */
private fun TextView.writeClip(clip: ClipData): Boolean {
  val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
  return try {
    clipboard.setPrimaryClip(clip)
    true
  } catch (e: RuntimeException) {
    Log.w(TAG, "Failed to copy to the clipboard", e)
    false
  }
}

/** Copies selection as both plain text and HTML with inline styles. Returns the plain text. */
private fun TextView.copyWithHTML(
  start: Int,
  end: Int,
): String? {
  if (start < 0 || start >= end) return null

  val spannable = text as? Spannable ?: return null
  val selectedText = spannable.subSequence(start, end)
  val plainText =
    if ((this as? AccessibleMarkdownTextView)?.copiesLinksAsMarkdown == true && selectedText is Spanned) {
      plainTextWithMarkdownLinks(selectedText)
    } else {
      selectedText.toString()
    }

  val styleConfig =
    (this as? EnrichedMarkdownText)?.markdownStyle
      ?: findParentMarkdownStyle()

  if (styleConfig != null && selectedText is Spannable) {
    // Density values convert device pixels back to CSS pixels
    val displayMetrics = context.resources.displayMetrics
    val isRTL = context.resources.isLayoutRTL()
    val html =
      HTMLGenerator.generateHTML(
        selectedText,
        styleConfig,
        displayMetrics.scaledDensity,
        displayMetrics.density,
        isRTL,
      )
    if (writeClip(ClipData.newHtmlText("EnrichedMarkdown", plainText, html))) return plainText
    // The HTML can be what took the clip over the limit, so plain text may still fit.
  }
  return plainText.takeIf { writeClip(ClipData.newPlainText("Text", plainText)) }
}

private fun TextView.copyMarkdownToClipboard(): String? {
  val markdown = MarkdownExtractor.getMarkdownForSelection(this) ?: return null
  return markdown.takeIf { writeClip(ClipData.newPlainText("Markdown", markdown)) }
}

/** Returns remote image URLs (http/https only) from the current selection. */
private fun TextView.getImageUrlsInSelection(): List<String> {
  val start = selectionStart
  val end = selectionEnd
  if (start < 0 || end < 0 || start >= end) return emptyList()

  val spannable = text as? Spannable ?: return emptyList()
  return spannable
    .getSpans(start, end, ImageSpan::class.java)
    .mapNotNull { it.imageUrl }
    .filter { it.startsWith("http://") || it.startsWith("https://") }
}

private fun TextView.copyImageUrlsToClipboard(): String? {
  val urls = getImageUrlsInSelection()
  if (urls.isEmpty()) return null

  val joined = urls.joinToString("\n")
  return joined.takeIf { writeClip(ClipData.newPlainText("Image URLs", joined)) }
}

private fun TextView.findParentMarkdownStyle(): StyleConfig? {
  var current: ViewParent? = parent
  while (current != null) {
    if (current is EnrichedMarkdown) return current.markdownStyle
    current = current.parent
  }
  return null
}

/** Plain text with each link as `[label](url)` (`copyLinksAs: 'markdown'`). Recognized links stay as their text. */
internal fun plainTextWithMarkdownLinks(text: Spanned): String {
  val out = StringBuilder()
  var start = 0
  while (start < text.length) {
    val end = text.nextSpanTransition(start, text.length, LinkSpan::class.java)
    val run = text.subSequence(start, end).toString()
    val link =
      text.getSpans(start, end, LinkSpan::class.java).firstOrNull {
        !it.recognizedLink && text.getSpanStart(it) <= start && text.getSpanEnd(it) >= end
      }
    out.append(if (link == null) run else MarkdownASTSerializer.markdownLink(run, link.url))
    start = end
  }
  return out.toString()
}
