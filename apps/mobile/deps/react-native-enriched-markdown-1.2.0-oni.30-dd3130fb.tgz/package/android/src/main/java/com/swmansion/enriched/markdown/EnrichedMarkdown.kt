package com.swmansion.enriched.markdown

import android.content.Context
import android.content.res.Configuration
import android.graphics.Canvas
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.view.Choreographer
import android.view.View
import android.view.ViewGroup
import androidx.core.view.children
import com.facebook.react.bridge.Arguments
import com.facebook.react.bridge.ReadableMap
import com.facebook.react.uimanager.PixelUtil
import com.facebook.react.uimanager.StateWrapper
import com.facebook.yoga.YogaMeasureOutput
import com.swmansion.enriched.markdown.accessibility.AccessibilityLabels
import com.swmansion.enriched.markdown.math.LatexErrorReporter
import com.swmansion.enriched.markdown.parser.Md4cFlags
import com.swmansion.enriched.markdown.parser.Parser
import com.swmansion.enriched.markdown.segments.BlockSlotSegmentView
import com.swmansion.enriched.markdown.segments.BlockquoteContainerView
import com.swmansion.enriched.markdown.segments.CodeBlockContainerView
import com.swmansion.enriched.markdown.segments.ContainerNodeView
import com.swmansion.enriched.markdown.segments.DynamicBlockProps
import com.swmansion.enriched.markdown.segments.MarkdownSegmentRenderer
import com.swmansion.enriched.markdown.segments.OverflowScrollView
import com.swmansion.enriched.markdown.segments.RenderedSegment
import com.swmansion.enriched.markdown.segments.SegmentViewConfig
import com.swmansion.enriched.markdown.segments.SegmentViewCreators
import com.swmansion.enriched.markdown.segments.SegmentViewFactory
import com.swmansion.enriched.markdown.segments.TableContainerView
import com.swmansion.enriched.markdown.segments.TextRenderCache
import com.swmansion.enriched.markdown.segments.splitASTIntoSegments
import com.swmansion.enriched.markdown.slots.BlockSlotLayer
import com.swmansion.enriched.markdown.slots.BlockSlotRevealController
import com.swmansion.enriched.markdown.slots.BlockSlotRevealTarget
import com.swmansion.enriched.markdown.slots.EnrichedMarkdownBlockSlotView
import com.swmansion.enriched.markdown.slots.SlotPlacements
import com.swmansion.enriched.markdown.spoiler.SpoilerOverlayMode
import com.swmansion.enriched.markdown.spoiler.forEachSpoilerCapableDescendant
import com.swmansion.enriched.markdown.styles.ImageSourceOverride
import com.swmansion.enriched.markdown.styles.LinkPillContent
import com.swmansion.enriched.markdown.styles.StyleConfig
import com.swmansion.enriched.markdown.utils.common.BreakStrategyUtils
import com.swmansion.enriched.markdown.utils.common.CodeBlockStreamingMode
import com.swmansion.enriched.markdown.utils.common.LinkRegexConfig
import com.swmansion.enriched.markdown.utils.common.MediaStreamingMode
import com.swmansion.enriched.markdown.utils.common.RenderCoordinator
import com.swmansion.enriched.markdown.utils.common.StreamingMarkdownFilter
import com.swmansion.enriched.markdown.utils.common.TableStreamingMode
import com.swmansion.enriched.markdown.utils.common.animatorDurationScale
import com.swmansion.enriched.markdown.utils.common.isReducedMotionEnabled
import com.swmansion.enriched.markdown.utils.common.layout.MarkdownWritingDirection
import com.swmansion.enriched.markdown.utils.common.layout.allowsTextPatches
import com.swmansion.enriched.markdown.utils.text.StreamingEffects
import com.swmansion.enriched.markdown.utils.text.StreamingEffectsAnimator
import com.swmansion.enriched.markdown.utils.text.StreamingPacer
import com.swmansion.enriched.markdown.utils.text.view.ImagePressHost
import com.swmansion.enriched.markdown.utils.text.view.OnSelectionCopy
import com.swmansion.enriched.markdown.utils.text.view.SelectionCopyFormat
import com.swmansion.enriched.markdown.utils.text.view.SelectionMenuConfig
import com.swmansion.enriched.markdown.utils.text.view.TextPressHost
import com.swmansion.enriched.markdown.utils.text.view.applySelectionColors
import com.swmansion.enriched.markdown.utils.text.view.emitImagePressEvent
import com.swmansion.enriched.markdown.utils.text.view.emitStreamingEndEvent
import com.swmansion.enriched.markdown.utils.text.view.emitTextPressEvent
import java.util.EnumSet
import java.util.WeakHashMap
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.ceil

class EnrichedMarkdown(
  context: Context,
) : ContainerNodeView(context),
  ImagePressHost,
  TextPressHost {
  internal enum class DirtyFlag {
    RECREATE_SEGMENTS,
    FORCE_HEIGHT,

    // Yoga already measured with inputs that changed after (the wrapped code
    // blocks a prop reset cleared), so it has to be asked to measure again.
    REMEASURE,
  }

  private val parser = Parser.shared
  private val mainHandler = Handler(Looper.getMainLooper())
  private val executor: ExecutorService = Executors.newSingleThreadExecutor()
  private val renderCoordinator = RenderCoordinator(executor, ::postToMain)

  // Streaming renders start on a display frame, one at a time: the next waits until the last has
  // applied, and [renderStride] frames after it while applying overruns the frame budget.
  private var pacedRenderInFlightSince = 0L
  private var pacedRenderRequested = false
  private var pacedFramePosted = false
  private var renderStride = 1
  private var framesUntilRender = 0
  private var healthyApplies = 0
  private var lastPacedRenderFrameNanos = 0L
  private val pacedFrame = Choreographer.FrameCallback { onPacedFrame(it) }

  // Reused by the next render on the executor (see TextRenderCache). Its key is this epoch,
  // bumped on the main thread whenever the views stop showing what it holds: recreated views,
  // a synchronous render it didn't see, a missed patch.
  private val textRenderCache = TextRenderCache()
  private var textRenderEpoch = 0L
  private val mathContainerClass: Class<*>? by lazy { SegmentViewCreators.mathContainerClass() }
  private val videoContainerClass: Class<*>? by lazy { SegmentViewCreators.videoContainerClass() }

  // Set when React Native drops the view for good. Detaching from the window is
  // not disposal: a view renders before its first attach and while detached.
  private var isDisposed = false
  internal val dirtyFlags = EnumSet.noneOf(DirtyFlag::class.java)
  private val textEffects = WeakHashMap<EnrichedMarkdownInternalText, StreamingEffectsAnimator>()
  private var effectsConfig = StreamingEffects.Config()

  // The stream ended and its last text has not been rendered yet: it still animates, then settles.
  private var streamEnding = false

  // The stream ended and onStreamingEnd waits for the render that shows the whole document.
  private var streamEndPending = false

  // Whether the view streams: after the prop turns off, smooth pacing keeps it on until the words
  // still waiting have appeared.
  var streaming: Boolean = false
    private set
  private var streamingProp = false
  private var streamingEnded = false

  /** streamingConfig.smooth: the view renders the markdown [pacer] has revealed so far. */
  var smooth: Boolean = false
    set(value) {
      if (field == value) return
      field = value
      renderPending = true
    }
  private val pacer =
    StreamingPacer(
      reveal = {
        renderedSource = it
        scheduleRender()
      },
      done = {
        stopStreaming()
        renderedSource = currentMarkdown
        scheduleRender()
      },
    )

  // The markdown renders take: all of [currentMarkdown], or what smooth pacing has revealed.
  private var renderedSource: String = ""

  fun setStreamingProp(value: Boolean) {
    if (streamingProp == value) return
    streamingProp = value
    if (value) {
      // A new stream: the one before it has ended, whether or not its last words drained or its
      // final render applied.
      if (streaming) streamEndPending = true
      emitStreamingEndIfPending()
      streaming = true
      streamEnding = false
      streamingEnded = false
      // The streaming filter only applies while this is on, so re-render to
      // show or hide the content it holds back.
      renderPending = true
      dirtyFlags += DirtyFlag.FORCE_HEIGHT
    } else {
      streamingEnded = true
    }
  }

  // The stream ended: the next render shows the whole document, and what still animates settles.
  private fun stopStreaming() {
    streaming = false
    streamEnding = true
    streamEndPending = true
    dirtyFlags += DirtyFlag.FORCE_HEIGHT
    finishStreamingAnimations()
    settleTextSegments(except = null)
    hintOverflowingBlocks(this)
  }

  // The scrollbar hints held back while streaming (OverflowScrollView.setOverflows). A nested
  // document hints when its own stream ends.
  private fun hintOverflowingBlocks(group: ViewGroup) {
    for (i in 0 until group.childCount) {
      when (val child = group.getChildAt(i)) {
        is OverflowScrollView -> child.hintOverflow()
        is EnrichedMarkdown -> Unit
        is ViewGroup -> hintOverflowingBlocks(child)
      }
    }
  }

  // After the first render scheduled once the stream ended: the last words are on screen.
  private fun emitStreamingEndIfPending() {
    if (!streamEndPending) return
    streamEndPending = false
    emitStreamingEndEvent()
  }

  /** Text segments start over with the new animation: 'none' shows what still animates at once. */
  fun setStreamingAnimation(config: StreamingEffects.Config) {
    if (config == effectsConfig) return
    effectsConfig = config
    textEffects.values.forEach { it.configure(config) }
    if (config.type == StreamingEffects.Type.NONE) finishStreamingAnimations()
  }

  // used to force a Yoga re-measure when a block image resolves its box height
  var stateWrapper: StateWrapper? = null
  private var forceHeightRecalculationCounter = 0

  var tableStreamingMode: TableStreamingMode = TableStreamingMode.PROGRESSIVE
    set(value) {
      if (field == value) return
      field = value
      dirtyFlags += DirtyFlag.FORCE_HEIGHT
      renderPending = true
    }
  var codeBlockStreamingMode: CodeBlockStreamingMode = CodeBlockStreamingMode.PROGRESSIVE
    set(value) {
      if (field == value) return
      field = value
      dirtyFlags += DirtyFlag.FORCE_HEIGHT
      renderPending = true
    }
  var mediaStreamingMode: MediaStreamingMode = MediaStreamingMode.PROGRESSIVE
    set(value) {
      if (field == value) return
      field = value
      dirtyFlags += DirtyFlag.FORCE_HEIGHT
      renderPending = true
    }
  private var renderPending: Boolean = false
  private var markdownChanged = false

  var currentMarkdown: String = ""
    private set

  var markdownStyle: StyleConfig? = null
    private set

  private var markdownStyleMap: ReadableMap? = null
  private var lastKnownFontScale: Float = context.resources.configuration.fontScale

  var md4cFlags: Md4cFlags = Md4cFlags.DEFAULT
    private set
  private var linkRegex: LinkRegexConfig? = null
  private var inlineCodeLinkRegex: LinkRegexConfig? = null
  private var isGFM: Boolean = true
  private var allowFontScaling: Boolean = true
  private var maxFontSizeMultiplier: Float = 0f
  private var imageRequestHeaders: Map<String, String> = emptyMap()
  private var imageSourceOverrides: Map<String, ImageSourceOverride> = emptyMap()
  private var linkPillContent: Map<String, LinkPillContent> = emptyMap()
  private var admonitionTitles: Map<String, String> = emptyMap()

  // Fabric children (the React slot views) live here, above the segments, so the
  // segment reconciler's child indices stay its own. Fabric positions them.
  val slotLayer = BlockSlotLayer(context)

  // From the shadow node's state: the placed slot children's ids and heights (px).
  private var activeBlockSlotIds: Set<String> = emptySet()
  private var blockSlotHeights: Map<String, Int> = emptyMap()
  private val blockSlotReveal =
    BlockSlotRevealController(durationScale = { animatorDurationScale(context) }) { stepBlockSlotReveal() }
  private var selectable: Boolean = true
  private var selectionColor: Int? = null
  private var selectionHandleColor: Int? = null
  private var selectionMenuConfig = SelectionMenuConfig()
  private var accessibilityLabels = AccessibilityLabels()
  private var textBreakStrategy: String = BreakStrategyUtils.DEFAULT_STRATEGY
  private var writingDirection = MarkdownWritingDirection.FIRST_STRONG

  private var onLinkPressCallback: ((String) -> Unit)? = null
  private var onLinkLongPressCallback: ((String) -> Unit)? = null
  private var onTaskListItemPressCallback: ((Int, Boolean, String) -> Unit)? = null
  private var onLatexErrorCallback: LatexErrorReporter? = null

  private val reportedLatexErrors = HashSet<String>()

  private val latexErrorReporter =
    LatexErrorReporter { source, message, displayMode ->
      val key = (if (displayMode) "B " else "I ") + source
      if (reportedLatexErrors.add(key)) {
        onLatexErrorCallback?.report(source, message, displayMode)
      }
    }
  private var contextMenuItemTexts: List<String> = emptyList()
  var onContextMenuItemPressCallback: ((itemText: String, selectedText: String, selectionStart: Int, selectionEnd: Int) -> Unit)? = null
  var onSelectionCopyCallback: OnSelectionCopy? = null
  var copiesLinksAsMarkdown: Boolean
    get() = dynamicProps.copiesLinksAsMarkdown
    set(value) {
      dynamicProps.copiesLinksAsMarkdown = value
    }

  var spoilerOverlay: SpoilerOverlayMode
    get() = dynamicProps.spoilerOverlay
    set(value) {
      if (dynamicProps.spoilerOverlay == value) return
      dynamicProps.spoilerOverlay = value
      // Nested blockquotes and table cells draw spoilers too, so the whole tree is updated.
      forEachSpoilerCapableDescendant(this) { it.spoilerOverlay = value }
    }
  var enableTaskListItemToggle: Boolean = true
    set(value) {
      if (field == value) return
      field = value
      segmentViews.filterIsInstance<EnrichedMarkdownInternalText>().forEach {
        it.enableTaskListItemToggle = value
      }
    }

  private val dynamicProps = DynamicBlockProps()

  var enableBlockContextMenu: Boolean
    get() = dynamicProps.enableBlockContextMenu
    set(value) {
      dynamicProps.enableBlockContextMenu = value
    }
  var enableCodeBlockPress: Boolean
    get() = dynamicProps.enableCodeBlockPress
    set(value) {
      dynamicProps.enableCodeBlockPress = value
    }

  private val codeBlockWrapState =
    CodeBlockWrapState(viewTag = { id }, codeBlockViews = ::codeBlockViews, onHeightChanged = ::onImageLayoutChanged)

  var enableCodeBlockWrapToggle: Boolean
    get() = codeBlockWrapState.enabled
    set(value) {
      if (codeBlockWrapState.setEnabled(value)) onImageLayoutChanged()
    }

  init {
    segmentViewFactory = RootFactory()
    // The layer stays the last child (applySegments places segments in front of
    // it), so it draws above them and touch lookup reaches the slots first.
    addView(slotLayer, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
    slotLayer.setOnHierarchyChangeListener(
      object : OnHierarchyChangeListener {
        // A child mounted mid grow-in is placed and clipped before it draws.
        override fun onChildViewAdded(
          parent: View?,
          child: View?,
        ) {
          applyBlockSlotReveal()
        }

        override fun onChildViewRemoved(
          parent: View?,
          child: View?,
        ) = Unit
      },
    )
  }

  // The slot layer spans the whole host, so the default order, by position,
  // would read every React replacement before the text above it.
  override fun slotViewsForAccessibility(): Map<String, View> =
    slotLayer.children.filterIsInstance<EnrichedMarkdownBlockSlotView>().associateBy { it.slotId }

  // isTaskToggle marks a checkbox flip rendered locally ahead of the prop; it
  // moves no code block, so it skips the wrap state's reset rule.
  fun setMarkdownContent(
    markdown: String,
    isTaskToggle: Boolean = false,
  ) {
    // The shadow node measures the new markdown before this setter runs, still
    // with the old wrapped set, so a reset needs Yoga to measure again.
    if (!isTaskToggle && codeBlockWrapState.onMarkdownProp(markdown, currentMarkdown)) {
      dirtyFlags += DirtyFlag.REMEASURE
    }
    if (currentMarkdown == markdown) return
    currentMarkdown = markdown
    markdownChanged = true
  }

  fun setMarkdownStyle(style: ReadableMap?) {
    markdownStyleMap = style
    val newConfig = style?.let { StyleConfig(it, context, allowFontScaling, maxFontSizeMultiplier) }
    newConfig?.imageRequestHeaders = imageRequestHeaders
    newConfig?.imageSourceOverrides = imageSourceOverrides
    newConfig?.linkPillContent = linkPillContent
    newConfig?.writingDirection = writingDirection
    newConfig?.admonitionTitles = admonitionTitles
    if (markdownStyle == newConfig) return
    markdownStyle = newConfig
    dirtyFlags += DirtyFlag.RECREATE_SEGMENTS
    dirtyFlags += DirtyFlag.FORCE_HEIGHT
    renderPending = true
  }

  fun setImageRequestHeaders(headers: Map<String, String>) {
    if (imageRequestHeaders == headers) return
    imageRequestHeaders = headers
    markdownStyle?.imageRequestHeaders = headers
    dirtyFlags += DirtyFlag.RECREATE_SEGMENTS
    renderPending = true
  }

  fun setAdmonitionTitles(titles: Map<String, String>) {
    if (admonitionTitles == titles) return
    admonitionTitles = titles
    markdownStyle?.admonitionTitles = titles
    dirtyFlags += DirtyFlag.RECREATE_SEGMENTS
    renderPending = true
  }

  fun setImageSources(sources: Map<String, ImageSourceOverride>) {
    if (imageSourceOverrides == sources) return
    imageSourceOverrides = sources
    markdownStyle?.imageSourceOverrides = sources
    dirtyFlags += DirtyFlag.RECREATE_SEGMENTS
    renderPending = true
  }

  /**
   * The shadow node's `slotPlacements` state: which slot children exist and how
   * tall the placed ones are. New ids need a render that claims their blocks; new
   * heights only restack the segments (Yoga already measured with them).
   */
  fun applySlotPlacements(state: ReadableMap?) {
    val placements = SlotPlacements.from(state)
    blockSlotHeights = placements.heightsPx
    blockSlotReveal.keepSlotIds(placements.ids)
    if (updateBlockSlotHeights(placements.heightsPx) && width > 0) {
      layoutSegments()
      requestLayout()
    }
    // Only placed children stand in for their blocks: an unplaced one (its block
    // is gone, or measurement fell back) leaves the native block in place.
    if (activeBlockSlotIds != placements.placed) {
      activeBlockSlotIds = placements.placed
      // Rendered now, in this commit, not in commitProps nor one executor hop later.
      renderPending = false
      renderSynchronously()
    }
  }

  fun setLinkPillContent(content: Map<String, LinkPillContent>) {
    if (linkPillContent == content) return
    linkPillContent = content
    markdownStyle?.linkPillContent = content
    // A label can change the pill's width and so the wrapped height.
    dirtyFlags += DirtyFlag.RECREATE_SEGMENTS
    dirtyFlags += DirtyFlag.FORCE_HEIGHT
    renderPending = true
  }

  // Smooth pacing lays out a new line before Yoga has given the view the height for it (that takes
  // a commit): until then the line stays inside the view rather than drawing over what follows.
  override fun dispatchDraw(canvas: Canvas) {
    if (!(streaming && smooth)) {
      super.dispatchDraw(canvas)
      return
    }
    val saved = canvas.save()
    // Vertically only: what draws past the sides without pacing still does.
    canvas.clipRect(-width.toFloat(), 0f, 2f * width, height.toFloat())
    super.dispatchDraw(canvas)
    canvas.restoreToCount(saved)
  }

  fun commitProps() {
    if (isDisposed) return
    MeasurementStore.updateFontScalingSettings(id, allowFontScaling, maxFontSizeMultiplier)
    if (renderPending || markdownChanged || streamingEnded) {
      streamingEnded = false
      // Smooth pacing renders what has been revealed and hands the rest over frame by frame, so
      // new markdown that reveals nothing yet renders nothing. When the prop turns off, the words
      // still waiting drain first, then streaming stops.
      if (pacer.update(currentMarkdown, streamingProp, smooth)) {
        stopStreaming()
        renderPending = true
      }
      val source = pacer.markdownToRender
      if (renderPending || source != renderedSource) {
        renderedSource = source
        scheduleRender()
      }
      renderPending = false
      markdownChanged = false
    }
  }

  override fun onConfigurationChanged(newConfig: Configuration) {
    super.onConfigurationChanged(newConfig)
    if (!allowFontScaling) return
    val newFontScale = newConfig.fontScale
    if (newFontScale != lastKnownFontScale) {
      lastKnownFontScale = newFontScale
      recreateStyleConfig()
      dirtyFlags += DirtyFlag.RECREATE_SEGMENTS
      dirtyFlags += DirtyFlag.FORCE_HEIGHT
      scheduleRender()
    }
  }

  fun setLinkRegex(config: LinkRegexConfig?) {
    if (linkRegex == config) return
    linkRegex = config
    renderPending = true
  }

  fun setInlineCodeLinkRegex(config: LinkRegexConfig?) {
    if (inlineCodeLinkRegex == config) return
    inlineCodeLinkRegex = config
    renderPending = true
  }

  fun setMd4cFlags(flags: Md4cFlags) {
    if (md4cFlags == flags) return
    md4cFlags = flags
    renderPending = true
  }

  fun setIsGFM(value: Boolean) {
    if (isGFM == value) return
    isGFM = value
    renderPending = true
  }

  fun setAllowFontScaling(allow: Boolean) {
    if (allowFontScaling == allow) return
    allowFontScaling = allow
    MeasurementStore.updateFontScalingSettings(id, allowFontScaling, maxFontSizeMultiplier)
    recreateStyleConfig()
    dirtyFlags += DirtyFlag.RECREATE_SEGMENTS
    dirtyFlags += DirtyFlag.FORCE_HEIGHT
    renderPending = true
  }

  fun setMaxFontSizeMultiplier(multiplier: Float) {
    if (maxFontSizeMultiplier == multiplier) return
    maxFontSizeMultiplier = multiplier
    MeasurementStore.updateFontScalingSettings(id, allowFontScaling, maxFontSizeMultiplier)
    recreateStyleConfig()
    dirtyFlags += DirtyFlag.RECREATE_SEGMENTS
    dirtyFlags += DirtyFlag.FORCE_HEIGHT
    renderPending = true
  }

  fun setAllowTrailingMargin(allow: Boolean) {
    if (trailingMarginEnabled == allow) return
    trailingMarginEnabled = allow
    dirtyFlags += DirtyFlag.RECREATE_SEGMENTS
    dirtyFlags += DirtyFlag.FORCE_HEIGHT
    renderPending = true
  }

  fun setIsSelectable(value: Boolean) {
    if (selectable == value) return
    selectable = value
    segmentViews.filterIsInstance<EnrichedMarkdownInternalText>().forEach {
      it.setIsSelectable(value)
    }
  }

  fun setSelectionColor(color: Int?) {
    if (selectionColor == color) return
    selectionColor = color
    applySelectionColorsToSegments()
  }

  fun setSelectionHandleColor(color: Int?) {
    if (selectionHandleColor == color) return
    selectionHandleColor = color
    applySelectionColorsToSegments()
  }

  fun setTextBreakStrategy(strategy: String) {
    if (textBreakStrategy == strategy) return
    textBreakStrategy = strategy
    MeasurementStore.updateBreakStrategy(id, strategy)
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
      val resolved = BreakStrategyUtils.resolveBreakStrategy(strategy)
      segmentViews.filterIsInstance<EnrichedMarkdownInternalText>().forEach {
        it.breakStrategy = resolved
      }
    }
    dirtyFlags += DirtyFlag.FORCE_HEIGHT
    renderPending = true
  }

  fun setWritingDirection(direction: MarkdownWritingDirection) {
    if (writingDirection == direction) return
    writingDirection = direction
    markdownStyle?.writingDirection = direction
    dirtyFlags += DirtyFlag.RECREATE_SEGMENTS
    dirtyFlags += DirtyFlag.FORCE_HEIGHT
    renderPending = true
  }

  private fun applySelectionColorsToSegments() {
    segmentViews.filterIsInstance<EnrichedMarkdownInternalText>().forEach {
      it.applySelectionColors(selectionColor, selectionHandleColor)
    }
  }

  fun setOnLinkPressCallback(callback: (String) -> Unit) {
    onLinkPressCallback = callback
  }

  fun setOnLinkLongPressCallback(callback: (String) -> Unit) {
    onLinkLongPressCallback = callback
  }

  fun setOnLatexErrorCallback(callback: LatexErrorReporter) {
    onLatexErrorCallback = callback
  }

  override var imagePressEnabled: Boolean = false
    private set

  override fun emitOnImagePress(
    url: String,
    altText: String,
  ) {
    emitImagePressEvent(url, altText)
  }

  fun setEnableImagePress(enabled: Boolean) {
    imagePressEnabled = enabled
  }

  override var textPressEnabled: Boolean = false
    private set

  override fun emitOnTextPress(
    index: Int,
    text: String,
  ) {
    emitTextPressEvent(index, text)
  }

  fun setEnableTextPress(enabled: Boolean) {
    textPressEnabled = enabled
  }

  fun setOnTaskListItemPressCallback(callback: ((taskIndex: Int, checked: Boolean, itemText: String) -> Unit)?) {
    onTaskListItemPressCallback = callback
  }

  fun setOnCopyPressCallback(callback: ((code: String, language: String) -> Unit)?) {
    dynamicProps.onCopyPress = callback
  }

  fun setOnCodeBlockPressCallback(callback: ((code: String, language: String) -> Unit)?) {
    dynamicProps.onCodeBlockPress = callback
  }

  fun setContextMenuItems(items: List<String>) {
    contextMenuItemTexts = items
    segmentViews.filterIsInstance<EnrichedMarkdownInternalText>().forEach {
      it.setContextMenuItems(items, ::forwardContextMenuItemPress)
    }
  }

  fun setSelectionMenuConfig(config: SelectionMenuConfig) {
    if (selectionMenuConfig == config) return
    selectionMenuConfig = config
    dynamicProps.copyLabel = config.copyLabel
    dynamicProps.copyAsMarkdownLabel = config.copyAsMarkdownLabel
    segmentViews.filterIsInstance<EnrichedMarkdownInternalText>().forEach {
      it.selectionMenuConfig = config
    }
  }

  fun setAccessibilityLabels(labels: AccessibilityLabels) {
    if (accessibilityLabels == labels) return
    accessibilityLabels = labels
    segmentViews.filterIsInstance<EnrichedMarkdownInternalText>().forEach {
      it.accessibilityLabels = labels
    }
    segmentViews.filterIsInstance<TableContainerView>().forEach {
      it.accessibilityLabels = labels
    }
    codeBlockViews().forEach {
      it.accessibilityLabels = labels
    }
    mathContainerClass?.let { mathClass ->
      segmentViews.filter { mathClass.isInstance(it) }.forEach { view ->
        runCatching {
          mathClass
            .getMethod("setAccessibilityLabels", AccessibilityLabels::class.java)
            .invoke(view, labels)
        }
      }
    }
  }

  private fun forwardContextMenuItemPress(
    itemText: String,
    selectedText: String,
    selectionStart: Int,
    selectionEnd: Int,
  ) {
    onContextMenuItemPressCallback?.invoke(itemText, selectedText, selectionStart, selectionEnd)
  }

  private fun forwardSelectionCopy(
    text: String,
    format: SelectionCopyFormat,
    selectionStart: Int,
    selectionEnd: Int,
    markdown: String,
  ) {
    onSelectionCopyCallback?.invoke(text, format, selectionStart, selectionEnd, markdown)
  }

  private fun recreateStyleConfig() {
    markdownStyleMap?.let {
      markdownStyle =
        StyleConfig(it, context, allowFontScaling, maxFontSizeMultiplier).also { config ->
          config.imageRequestHeaders = imageRequestHeaders
          config.imageSourceOverrides = imageSourceOverrides
          config.linkPillContent = linkPillContent
          config.writingDirection = writingDirection
          config.admonitionTitles = admonitionTitles
        }
    }
  }

  // Everything one render needs, captured on the main thread.
  private class RenderJob(
    val style: StyleConfig,
    val markdown: String,
    val isStreaming: Boolean,
    val tableMode: TableStreamingMode,
    val codeBlockMode: CodeBlockStreamingMode,
    val mediaMode: MediaStreamingMode,
    val textLinkRegex: LinkRegexConfig?,
    val codeLinkRegex: LinkRegexConfig?,
    val slotIds: Set<String>,
    val annotateImages: Boolean,
  )

  private fun renderJob(): RenderJob? {
    val style = markdownStyle ?: return null
    val markdown = renderedSource.takeIf { it.isNotEmpty() } ?: return null
    return RenderJob(
      style,
      markdown,
      streaming,
      tableStreamingMode,
      codeBlockStreamingMode,
      mediaStreamingMode,
      linkRegex,
      inlineCodeLinkRegex,
      activeBlockSlotIds,
      imageSourceOverrides.isNotEmpty(),
    )
  }

  // Parses and renders off the main thread's state; safe on any thread.
  private fun runRenderJob(
    job: RenderJob,
    cache: TextRenderCache? = null,
    cacheKey: Long = 0L,
  ): RenderOutcome {
    val flags = md4cFlags
    val filtered =
      if (job.isStreaming) {
        StreamingMarkdownFilter.renderableMarkdownForStreaming(
          job.markdown,
          flags,
          job.tableMode,
          job.codeBlockMode,
          job.mediaMode,
          tables = isGFM,
        )
      } else {
        null
      }
    val renderableMarkdown = filtered?.markdown ?: job.markdown
    val hasPendingCodeBlock = filtered?.endsInsideOpenCodeFence ?: false
    val showsOnlyFinishedBlocks = filtered?.showsOnlyFinishedBlocks ?: false
    if (renderableMarkdown.isEmpty()) return RenderOutcome(emptyList(), false, showsOnlyFinishedBlocks)

    val ast =
      parser.parseMarkdown(
        renderableMarkdown,
        flags,
        isGFM,
        job.textLinkRegex,
        job.codeLinkRegex,
        job.slotIds,
        job.annotateImages,
      ) ?: return RenderOutcome(emptyList(), false, false)

    val segments = splitASTIntoSegments(ast)
    cache?.begin(cacheKey)
    val renderedSegments =
      MarkdownSegmentRenderer.render(
        segments,
        job.style,
        context,
        onLinkPressCallback,
        onLinkLongPressCallback,
        onLatexError = latexErrorReporter,
        cache = cache,
      )
    cache?.end()
    return RenderOutcome(renderedSegments, hasPendingCodeBlock, showsOnlyFinishedBlocks)
  }

  private class RenderOutcome(
    val segments: List<RenderedSegment>,
    val hasPendingCodeBlock: Boolean,
    // Everything shown is finished: the next block is still held back.
    val showsOnlyFinishedBlocks: Boolean,
  )

  // Paced while streaming without smooth pacing or arrival fades, which keep their own timing.
  private fun scheduleRender() {
    if (isDisposed) return
    if (streaming && !smooth && !fadesArrivals()) {
      pacedRenderRequested = true
      postPacedFrame()
      return
    }
    // This render supersedes a paced one still waiting (the stream ended, say).
    pacedRenderRequested = false
    scheduleRenderNow(paced = false)
  }

  private fun pacedRenderInFlight() =
    pacedRenderInFlightSince != 0L && SystemClock.uptimeMillis() - pacedRenderInFlightSince < PACED_RENDER_TIMEOUT_MS

  private fun postPacedFrame() {
    if (pacedFramePosted || pacedRenderInFlight()) return
    pacedFramePosted = true
    Choreographer.getInstance().postFrameCallback(pacedFrame)
  }

  private fun onPacedFrame(frameTimeNanos: Long) {
    pacedFramePosted = false
    if (isDisposed || !pacedRenderRequested) return
    // Each render is a layout pass and a frame: at most one every PACED_RENDER_INTERVAL_NANOS.
    if (framesUntilRender > 0 || frameTimeNanos - lastPacedRenderFrameNanos < PACED_RENDER_INTERVAL_NANOS) {
      if (framesUntilRender > 0) framesUntilRender--
      postPacedFrame()
      return
    }
    pacedRenderRequested = false
    framesUntilRender = renderStride - 1
    lastPacedRenderFrameNanos = frameTimeNanos
    scheduleRenderNow(paced = true)
  }

  private fun onPacedRenderApplied(applyMs: Long) {
    pacedRenderInFlightSince = 0L
    val frameMs = 1000f / (display?.refreshRate?.takeIf { it > 0f } ?: 60f)
    if (applyMs > frameMs * APPLY_BUDGET_SHARE) {
      renderStride = (renderStride * 2).coerceAtMost(MAX_RENDER_STRIDE)
      healthyApplies = 0
    } else if (renderStride > 1 && ++healthyApplies >= HEALTHY_APPLIES_TO_RELAX) {
      renderStride /= 2
      healthyApplies = 0
    }
    if (pacedRenderRequested) postPacedFrame()
  }

  private fun scheduleRenderNow(paced: Boolean) {
    pacedRenderInFlightSince = 0L
    val job =
      renderJob() ?: run {
        // Nothing to render: nothing is left to show either.
        if (!streaming) emitStreamingEndIfPending()
        return
      }
    if (paced) pacedRenderInFlightSince = SystemClock.uptimeMillis()
    // Taken now: an older render can still apply after a newer one is scheduled, and
    // must not claim the newer one's flags.
    val scheduledFlags = EnumSet.copyOf(dirtyFlags)
    // Recreated views hold none of the cached buffers. Every style input recreates them, so the
    // epoch is all the key needs.
    if (DirtyFlag.RECREATE_SEGMENTS in scheduledFlags) textRenderEpoch++
    val cacheKey = textRenderEpoch
    val patches = writingDirection.allowsTextPatches(job.markdown, layoutDirection == LAYOUT_DIRECTION_RTL)
    renderCoordinator.schedule {
      val outcome =
        try {
          if (!patches) textRenderCache.clear()
          runRenderJob(job, textRenderCache.takeIf { patches }, cacheKey)
        } catch (e: Exception) {
          textRenderCache.clear()
          Log.e(TAG, "Render failed", e)
          RenderOutcome(emptyList(), false, false)
        }
      Runnable {
        val epoch = textRenderEpoch
        val applyStart = SystemClock.uptimeMillis()
        applyRenderedSegments(
          outcome.segments,
          outcome.hasPendingCodeBlock,
          scheduledFlags,
          job.markdown,
          outcome.showsOnlyFinishedBlocks,
        )
        if (paced) onPacedRenderApplied(SystemClock.uptimeMillis() - applyStart)
        // A segment that missed a patch renders again in full (a new epoch): that render shows the end.
        if (!job.isStreaming && textRenderEpoch == epoch) emitStreamingEndIfPending()
      }
    }
  }

  // A slot id change arrives with the commit that mounts the React child, so the
  // placeholder that reserves its space must land in the same frame: render inline
  // instead of one executor hop later, and drop any render already in flight.
  private fun renderSynchronously() {
    if (isDisposed) return
    val job = renderJob() ?: return
    renderCoordinator.invalidate()
    pacedRenderInFlightSince = 0L
    pacedRenderRequested = false
    textRenderEpoch++
    val outcome =
      try {
        runRenderJob(job)
      } catch (e: Exception) {
        Log.e(TAG, "Render failed", e)
        RenderOutcome(emptyList(), false, false)
      }
    val epoch = textRenderEpoch
    applyRenderedSegments(outcome.segments, outcome.hasPendingCodeBlock, EnumSet.copyOf(dirtyFlags), job.markdown)
    if (!job.isStreaming && textRenderEpoch == epoch) emitStreamingEndIfPending()
  }

  // Trailing code block whose closing fence hasn't streamed in yet, if any.
  private var pendingCodeBlockSegment: RenderedSegment.CodeBlock? = null

  // [scheduledFlags] are the ones set when this render was scheduled: it takes them all, though an
  // earlier render took them too (a second style change in flight has its own), and flags set since
  // stay for the newer render they belong to.
  internal fun applyRenderedSegments(
    renderedSegments: List<RenderedSegment>,
    hasPendingCodeBlock: Boolean,
    scheduledFlags: Set<DirtyFlag>,
    renderedMarkdown: String,
    showsOnlyFinishedBlocks: Boolean = false,
  ) {
    laidOutMarkdown = renderedMarkdown
    pendingCodeBlockSegment =
      if (hasPendingCodeBlock) renderedSegments.lastOrNull() as? RenderedSegment.CodeBlock else null

    val flags = scheduledFlags
    dirtyFlags.removeAll(flags)
    val reset = DirtyFlag.RECREATE_SEGMENTS in flags
    val forceHeight = DirtyFlag.FORCE_HEIGHT in flags
    val remeasure = DirtyFlag.REMEASURE in flags

    val topologyChanged = applySegments(renderedSegments, reset)
    streamEnding = false
    // The last text settles too once everything shown is finished: the next block is held back.
    if (streaming) settleTextSegments(except = if (showsOnlyFinishedBlocks) null else segmentViews.lastOrNull())
    // A view that missed a patch gets the whole text from a full render: forgetting its signature
    // makes the reconciler update it then, where it would keep a view whose segment it matches.
    val missedPatches = SegmentViewCreators.syncTextRevisions(renderedSegments, segmentViews)
    if (missedPatches.isNotEmpty()) {
      missedPatches.forEach { segmentSignatures[it] = UNKNOWN_SIGNATURE }
      textRenderEpoch++
      scheduleRender()
    }
    updateBlockSlotHeights(blockSlotHeights)

    // A just-closed block has unchanged content, so the reconciler reuses it
    // without an update; sync pending here to trigger its deferred highlight.
    segmentViews.forEachIndexed { index, view ->
      if (view is CodeBlockContainerView) {
        view.pending = pendingCodeBlockSegment != null && index == segmentViews.size - 1
      }
    }
    codeBlockWrapState.sync()

    if (width > 0) {
      val heightBefore = computeSegmentsTotalHeight()
      layoutSegments()
      val heightAfter = computeSegmentsTotalHeight()

      if (forceHeight || topologyChanged || heightBefore != heightAfter) {
        MeasurementStore.invalidate(id)
        requestLayout()
        stateWrapper?.let {
          val state = Arguments.createMap()
          state.putInt("forceHeightRecalculationCounter", ++forceHeightRecalculationCounter)
          it.updateState(state)
        }
      }
    }
    if (remeasure) onImageLayoutChanged()
  }

  private fun isMathContainerView(view: View): Boolean = mathContainerClass?.isInstance(view) == true

  private fun isVideoContainerView(view: View): Boolean = videoContainerClass?.isInstance(view) == true

  private fun segmentViewConfig(): SegmentViewConfig =
    SegmentViewConfig(
      context = context,
      style = markdownStyle!!,
      allowFontScaling = allowFontScaling,
      maxFontSizeMultiplier = maxFontSizeMultiplier,
      accessibilityLabels = accessibilityLabels,
      selectionMenuConfig = selectionMenuConfig,
      textBreakStrategy = textBreakStrategy,
      selectable = selectable,
      selectionColor = selectionColor,
      selectionHandleColor = selectionHandleColor,
      contextMenuItemTexts = contextMenuItemTexts,
      dynamicProps = dynamicProps,
      onLinkPress = onLinkPressCallback,
      onLinkLongPress = onLinkLongPressCallback,
      onTaskListItemPress = onTaskListItemPressCallback,
      onContextMenuItemPress = ::forwardContextMenuItemPress,
      onLatexError = latexErrorReporter,
      onSelectionCopy = ::forwardSelectionCopy,
    )

  /**
   * Root factory: builds child views through the shared creators, then layers on
   * root-only concerns (spoiler overlay mode, task-list toggle, streaming tail /
   * fade-in animation, and the pending code block sync for the open trailing
   * fence).
   */
  private inner class RootFactory : SegmentViewFactory {
    override fun matchesKind(
      view: View,
      segment: RenderedSegment,
    ): Boolean =
      when (segment) {
        is RenderedSegment.Text -> view is EnrichedMarkdownInternalText
        is RenderedSegment.Table -> view is TableContainerView
        is RenderedSegment.Math -> isMathContainerView(view)
        is RenderedSegment.CodeBlock -> view is CodeBlockContainerView
        is RenderedSegment.Blockquote -> view is BlockquoteContainerView
        is RenderedSegment.Video -> isVideoContainerView(view)
        is RenderedSegment.BlockSlot -> view is BlockSlotSegmentView
      }

    override fun createView(segment: RenderedSegment): View {
      val config = segmentViewConfig()
      return when (segment) {
        is RenderedSegment.Text -> {
          SegmentViewCreators.createTextView(segment, config).apply {
            enableTaskListItemToggle = this@EnrichedMarkdown.enableTaskListItemToggle
          }
        }

        is RenderedSegment.Table -> {
          SegmentViewCreators.createTableView(segment, config)
        }

        is RenderedSegment.Math -> {
          SegmentViewCreators.createMathView(segment, config)
        }

        is RenderedSegment.CodeBlock -> {
          SegmentViewCreators.createCodeBlockView(segment, config).apply {
            pending = segment === pendingCodeBlockSegment
          }
        }

        is RenderedSegment.Blockquote -> {
          SegmentViewCreators.createBlockquoteView(segment, config)
        }

        is RenderedSegment.Video -> {
          SegmentViewCreators.createVideoView(segment, config)
        }

        is RenderedSegment.BlockSlot -> {
          SegmentViewCreators.createBlockSlotView(segment, config).apply {
            slotHeight = blockSlotHeights[segment.slotId] ?: 0
          }
        }
      }
    }

    override fun updateView(
      view: View,
      segment: RenderedSegment,
    ) {
      when (segment) {
        is RenderedSegment.Text -> {
          val textView = view as EnrichedMarkdownInternalText
          val tailStart = textView.text?.length ?: 0
          SegmentViewCreators.updateTextView(textView, segment)
          animateTextViewTail(textView, tailStart)
        }

        is RenderedSegment.Table -> {
          val tableView = view as TableContainerView
          val previousRowCount = tableView.rowCount
          val previousWidths = tableView.shownColumnWidths
          SegmentViewCreators.updateTableView(tableView, segment)
          if (fadesArrivals()) {
            tableView.animateNewRows(previousRowCount, BLOCK_FADE_DURATION_MS)
            // A wider cell widens its column smoothly, not in one jump.
            tableView.animateColumnWidths(previousWidths, COLUMN_WIDTHS_DURATION_MS)
          }
        }

        is RenderedSegment.Math -> {
          SegmentViewCreators.updateMathView(view, segment)
        }

        is RenderedSegment.CodeBlock -> {
          (view as CodeBlockContainerView).apply {
            pending = segment === pendingCodeBlockSegment
            applyCodeBlockNode(segment.node)
          }
        }

        is RenderedSegment.Blockquote -> {
          (view as BlockquoteContainerView).applyBlockquoteNode(segment.node, segment.taskIndexOffset)
        }

        is RenderedSegment.Video -> {
          SegmentViewCreators.updateVideoView(view, segment)
        }

        is RenderedSegment.BlockSlot -> {
          SegmentViewCreators.updateBlockSlotView(view as BlockSlotSegmentView, segment)
        }
      }
    }

    override fun animateNewView(
      view: View,
      segment: RenderedSegment,
    ) {
      when (segment) {
        is RenderedSegment.Text -> animateTextViewTail(view as EnrichedMarkdownInternalText, 0)

        is RenderedSegment.Table,
        is RenderedSegment.Math,
        is RenderedSegment.CodeBlock,
        is RenderedSegment.Blockquote,
        is RenderedSegment.Video,
        -> animateBlockViewFadeIn(view)

        // The placeholder draws nothing; it grows in once its height arrives.
        is RenderedSegment.BlockSlot -> Unit
      }
    }
  }

  // A text segment the reconciler drops frees its effects.
  override fun onViewRemoved(child: View) {
    super.onViewRemoved(child)
    if (child is EnrichedMarkdownInternalText) textEffects.remove(child)?.release()
  }

  private fun effectsOf(view: EnrichedMarkdownInternalText): StreamingEffectsAnimator =
    textEffects.getOrPut(view) {
      StreamingEffectsAnimator(view).also { it.configure(effectsConfig) }
    }

  private fun animateTextViewTail(
    view: EnrichedMarkdownInternalText,
    tailStart: Int,
  ) {
    if (!streaming && !streamEnding) return
    // Nothing animates: no animator is made for it, and those made already started over with 'none'
    // or turn it off on arrival (Reduce Motion).
    if (effectsConfig.type == StreamingEffects.Type.NONE) return
    if (view !in textEffects && isReducedMotionEnabled(context)) return
    val effects = effectsOf(view)
    effects.noteArrival(tailStart, view.text?.length ?: 0)
    if (streamEnding) effects.finish()
  }

  // What still animates in text segments settles: all of them once the stream ends, or the ones the
  // document's end has left (a gradient follows only the end of the document).
  private fun settleTextSegments(except: View?) {
    for (view in segmentViews) {
      if (view === except || view !is EnrichedMarkdownInternalText) continue
      val effects = textEffects[view] ?: continue
      // A fade ends on its own.
      if (effects.type == StreamingEffects.Type.GRADIENT) effects.finish()
    }
  }

  // New streamed content fades in and slots grow in, unless the animation is 'none' or Reduce Motion is on.
  private fun fadesArrivals() = streaming && effectsConfig.type != StreamingEffects.Type.NONE && !isReducedMotionEnabled(context)

  private fun animateBlockViewFadeIn(view: View) {
    if (!fadesArrivals()) return
    view.alpha = 0f
    view
      .animate()
      .alpha(1f)
      .setDuration(BLOCK_FADE_DURATION_MS)
      .start()
  }

  internal fun postToMain(action: Runnable) {
    mainHandler.post {
      if (!isDisposed) action.run()
    }
  }

  override fun onLayout(
    changed: Boolean,
    l: Int,
    t: Int,
    r: Int,
    b: Int,
  ) {
    layoutSegments()
    slotLayer.layout(0, 0, width, height)
  }

  // The markdown the segments show, behind the prop while a render is in flight.
  private var laidOutMarkdown = ""

  override fun layoutSegments() {
    super.layoutSegments()
    publishLaidOutSize()
  }

  // What the shadow node takes for a stream's next update instead of measuring the
  // whole document again (MeasurementStore.storeLaidOutSize). Published by every
  // layout of the segments, ahead of the height update it may ask for.
  private fun publishLaidOutSize() {
    if (width <= 0 || segmentViews.isEmpty()) {
      MeasurementStore.clearLaidOutSize(id)
      return
    }
    val contentWidth = (width - paddingLeft - paddingRight).toFloat()
    val (contentHeightPx, slots) = reservedSlotLayout()
    val contentHeight = contentHeightPx.toFloat()
    val hugged = huggedContentWidthPx(contentWidth)
    MeasurementStore.storeLaidOutSize(
      id,
      contentWidth,
      YogaMeasureOutput.make(PixelUtil.toDIPFromPixel(hugged ?: contentWidth), PixelUtil.toDIPFromPixel(contentHeight)),
      laidOutMarkdown,
      slots,
      fitsWiderWidths = hugged != null,
    )
  }

  // Narrower than it was measured at, with only text that lays out as at any wider width: the
  // widest line, as a measurement at a wider width returns it.
  private fun huggedContentWidthPx(contentWidth: Float): Float? {
    val measuredWidth = MeasurementStore.contentBoxWidthPx(id) ?: return null
    if (contentWidth + 1f >= measuredWidth) return null
    var widest = 0f
    for (view in segmentViews) {
      val layout = (view as? EnrichedMarkdownInternalText)?.layout ?: return null
      if (!MeasurementStore.laysOutAtAnyWiderWidth(layout)) return null
      for (line in 0 until layout.lineCount) widest = maxOf(widest, ceil(layout.getLineWidth(line)))
    }
    return widest
  }

  /** A root slot getting its first height while streaming grows into place ([BlockSlotRevealController]). */
  private fun updateBlockSlotHeights(heights: Map<String, Int>): Boolean {
    val changed = applyBlockSlotHeights(heights)
    blockSlotReveal.noteHeights(heights, segmentViews, fadesArrivals())
    applyBlockSlotReveal()
    return changed
  }

  private fun applyBlockSlotReveal() {
    val targets = (0 until slotLayer.childCount).mapNotNull { slotLayer.getChildAt(it) as? BlockSlotRevealTarget }
    blockSlotReveal.apply(segmentViews, targets)
  }

  private fun stepBlockSlotReveal() {
    applyBlockSlotReveal()
    if (width > 0) layoutSegments()
  }

  // Shows what is still fading in at once.
  private fun finishStreamingAnimations() {
    blockSlotReveal.cancel()
    stepBlockSlotReveal()
    for (view in segmentViews) {
      when {
        view is TableContainerView -> {
          view.finishRowFade()
        }

        view !is EnrichedMarkdownInternalText && view.alpha < 1f -> {
          view.animate().cancel()
          view.alpha = 1f
        }
      }
    }
  }

  fun onImageLayoutChanged() {
    if (isDisposed) return
    if (width > 0) {
      layoutSegments()
      requestLayout()
    }
    MeasurementStore.invalidateForContentResize(id)
    val wrapper = stateWrapper ?: return
    val state = Arguments.createMap()
    state.putInt("forceHeightRecalculationCounter", ++forceHeightRecalculationCounter)
    wrapper.updateState(state)
  }

  // Shutting the executor down does not cancel results it already posted, nor a
  // render that ignores the interrupt and posts afterwards, so drop those here
  // and refuse further work instead of applying it to a view React has dropped.
  fun cleanup() {
    isDisposed = true
    renderCoordinator.invalidate()
    Choreographer.getInstance().removeFrameCallback(pacedFrame)
    blockSlotReveal.reset()
    executor.shutdownNow()
    mainHandler.removeCallbacksAndMessages(null)
    stateWrapper = null
    textEffects.values.forEach { it.release() }
    textEffects.clear()
    pacer.release()
  }

  companion object {
    // A paced render whose apply never comes (dropped by invalidate) holds the next one back no longer.
    private const val PACED_RENDER_TIMEOUT_MS = 250L
    private const val MAX_RENDER_STRIDE = 4

    // Just under two 60 Hz frames, so a render every other one passes despite frame time jitter.
    private const val PACED_RENDER_INTERVAL_NANOS = 30_000_000L

    // Applying a render beyond this share of a frame raises the stride; this many in a row within
    // it lower it again.
    private const val APPLY_BUDGET_SHARE = 0.7f
    private const val HEALTHY_APPLIES_TO_RELAX = 8

    private const val TAG = "EnrichedMarkdown"
    private const val BLOCK_FADE_DURATION_MS = 200L
    private const val COLUMN_WIDTHS_DURATION_MS = 250L

    // A signature practically no segment has (they are FNV hashes salted per kind).
    private const val UNKNOWN_SIGNATURE = Long.MIN_VALUE
  }
}
