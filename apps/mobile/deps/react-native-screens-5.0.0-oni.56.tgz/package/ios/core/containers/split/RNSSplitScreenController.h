#pragma once

#import <UIKit/UIKit.h>
#import "RNSViewControllerViewLifecycleEventsObserver.h"

@class RNSSplitScreenController;
@class RNSStackNavigationController;

NS_ASSUME_NONNULL_BEGIN

/**
 * @protocol RNSSplitScreenControllerDelegate
 * @brief Receives layout and lifecycle notifications of a Split column from its controller.
 */
@protocol RNSSplitScreenControllerDelegate <NSObject>

/**
 * @brief Called whenever the column frame changes.
 *
 * @param frame The column frame in the coordinate space of the SplitHost controller's view, or the column view frame
 * as is when the column is presented outside the SplitHost subtree (e.g. the inspector as a modal).
 */
- (void)splitScreenController:(RNSSplitScreenController *)controller didChangeColumnFrame:(CGRect)frame;

- (void)splitScreenControllerWillAppear:(RNSSplitScreenController *)controller;
- (void)splitScreenControllerDidAppear:(RNSSplitScreenController *)controller;
- (void)splitScreenControllerWillDisappear:(RNSSplitScreenController *)controller;
- (void)splitScreenControllerDidDisappear:(RNSSplitScreenController *)controller;

@end

/**
 * @class RNSSplitScreenController
 * @brief A UIViewController subclass that manages a Split column in a UISplitViewController.
 *
 * It observes the column layout and lifecycle and reports them to its delegate.
 *
 * The lifecycle of the column is the one of the view of the navigation controller the Split installs for it. In a
 * column that hosts a stack it is the navigation controller of the stack, and this controller has to be set as its
 * `viewLifecycleEventsObserver`.
 */
@interface RNSSplitScreenController : UIViewController <RNSViewControllerViewLifecycleEventsObserver>

@property (nonatomic, weak, nullable) id<RNSSplitScreenControllerDelegate> delegate;

#pragma mark - Navigation controller

/**
 * @brief The navigation controller the Split installs for a plain column, i.e. a column that does not host a stack.
 * It is rooted at this controller.
 *
 * Created on first access and kept until `releasePlainColumnNavigationController`.
 */
@property (nonatomic, strong, readonly) RNSStackNavigationController *plainColumnNavigationController;

/**
 * @brief Releases `plainColumnNavigationController`.
 *
 * The navigation controller retains this controller as its root, so the column has to call it before it is destroyed.
 */
- (void)releasePlainColumnNavigationController;

#pragma mark - Signals

/**
 * @brief Determines if this controller is nested inside a SplitHost hierarchy.
 *
 * Used to differentiate between screens embedded in the native host and modal presentations.
 *
 * @return true if inside RNSSplitHostController, false otherwise.
 */
- (BOOL)isInSplitHostSubtree;

- (void)setNeedsLifecycleStateUpdate;

#pragma mark - Layout

/**
 * @brief Reports the column frame change after the Split repositioned its columns.
 *
 * @param splitViewController The UISplitViewController whose layout positioning changed, represented by
 * RNSSplitHostController.
 */
- (void)columnPositioningDidChangeInSplitViewController:(UISplitViewController *)splitViewController;

@end

NS_ASSUME_NONNULL_END
